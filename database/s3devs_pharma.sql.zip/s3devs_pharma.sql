-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 02, 2021 at 09:24 AM
-- Server version: 10.1.48-MariaDB
-- PHP Version: 7.2.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `s3devs_pharma`
--

-- --------------------------------------------------------

--
-- Table structure for table `activations`
--

DROP TABLE IF EXISTS `activations`;
CREATE TABLE `activations` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activations`
--

INSERT INTO `activations` (`id`, `user_id`, `code`, `completed`, `completed_at`, `created_at`, `updated_at`) VALUES
(1, 1, '5lsiEsJux1ElRPUjxDOq1YAo8GfUgG51', 1, '2021-01-02 08:19:39', '2021-01-02 08:19:39', '2021-01-02 08:19:39'),
(2, 2, 'QU0PrXlRpshmc3JvYRHAcrXCRMDLqYmr', 1, '2021-01-02 08:19:42', '2021-01-02 08:19:41', '2021-01-02 08:19:42'),
(3, 3, 'tXtULpxxm3OPaBpuamjRlx1CaQfHuQ9x', 1, '2021-01-02 08:19:44', '2021-01-02 08:19:43', '2021-01-02 08:19:44'),
(4, 4, 'H8zIgfVqQ4A7xRjPknT7crToWbvupUfn', 1, '2021-01-02 08:19:46', '2021-01-02 08:19:45', '2021-01-02 08:19:46'),
(5, 5, 'Dm9A5BFZGnfTZKAIDSNJl8XNsprna25n', 1, '2021-01-02 08:19:48', '2021-01-02 08:19:47', '2021-01-02 08:19:48'),
(6, 6, '5plf6KJDNWHcmU9fAtPIpodj1ES5PgD0', 1, '2021-01-02 08:19:50', '2021-01-02 08:19:50', '2021-01-02 08:19:50');

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
CREATE TABLE `activities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `user_id`, `name`, `module`, `action`, `notes`, `created_at`, `updated_at`) VALUES
(1, 1, 'Admin AndIt', 'Category', 'Added', 'Added a New Referral Categroy', '2021-01-02 08:20:44', '2021-01-02 08:20:44'),
(2, 1, 'Admin AndIt', 'patient', 'Added', 'Added a New patient', '2021-01-02 08:22:07', '2021-01-02 08:22:07');

-- --------------------------------------------------------

--
-- Table structure for table `asset_categories`
--

DROP TABLE IF EXISTS `asset_categories`;
CREATE TABLE `asset_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_equipment`
--

DROP TABLE IF EXISTS `asset_equipment`;
CREATE TABLE `asset_equipment` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `item_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identification_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `serial_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_status` enum('Usable','Not Usable','Repairable') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Usable',
  `condition` enum('Good','Average','Damage') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Good',
  `received_date` date NOT NULL,
  `acquisition_cost` decimal(8,2) NOT NULL DEFAULT '0.00',
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_locations`
--

DROP TABLE IF EXISTS `asset_locations`;
CREATE TABLE `asset_locations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bank_accounts`
--

DROP TABLE IF EXISTS `bank_accounts`;
CREATE TABLE `bank_accounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `bank_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branch_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` decimal(8,2) DEFAULT '0.00',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bank_transections`
--

DROP TABLE IF EXISTS `bank_transections`;
CREATE TABLE `bank_transections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `bank_account_id` bigint(20) UNSIGNED NOT NULL,
  `trnsactionId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transection_type` enum('debit','credit') COLLATE utf8mb4_unicode_ci NOT NULL,
  `checkOrslip_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bed_charge_collections`
--

DROP TABLE IF EXISTS `bed_charge_collections`;
CREATE TABLE `bed_charge_collections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `invoice` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_total` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(8,2) NOT NULL DEFAULT '0.00',
  `paid_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `due` decimal(8,2) NOT NULL DEFAULT '0.00',
  `advance` decimal(8,2) NOT NULL DEFAULT '0.00',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `bed_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `patient_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `admission_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `trans_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bed_charge_collection_items`
--

DROP TABLE IF EXISTS `bed_charge_collection_items`;
CREATE TABLE `bed_charge_collection_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `collection_date` date NOT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `bed_charge_collection_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
CREATE TABLE `currencies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `symbol` varchar(191) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`id`, `country`, `currency`, `code`, `symbol`) VALUES
(1, 'Albaniaa', 'Leke', 'ALL', 'Lek'),
(2, 'America', 'Dollars', 'USD', '$'),
(3, 'Afghanistan', 'Afghanis', 'AFN', '؋'),
(4, 'Argentina', 'Pesos', 'ARS', '$'),
(5, 'Aruba', 'Guilders', 'AWG', 'ƒ'),
(6, 'Australia', 'Dollars', 'AUD', '$'),
(7, 'Azerbaijan', 'New Manats', 'AZN', 'ман'),
(8, 'Bahamas', 'Dollars', 'BSD', '$'),
(9, 'Bangladesh', 'Taka', 'BDT', '৳'),
(10, 'Barbados', 'Dollars', 'BBD', '$'),
(11, 'Belarus', 'Rubles', 'BYR', 'p.'),
(12, 'Belgium', 'Euro', 'EUR', '€'),
(13, 'Beliz', 'Dollars', 'BZD', 'BZ$'),
(14, 'Bermuda', 'Dollars', 'BMD', '$'),
(15, 'Bolivia', 'Bolivianos', 'BOB', 'b$'),
(16, 'Bosnia and Herzegovina', 'Convertible Marka', 'BAM', 'KM'),
(17, 'Botswana', 'Pula', 'BWP', 'P'),
(18, 'Bulgaria', 'Leva', 'BGN', 'лв'),
(19, 'Brazil', 'Reais', 'BRL', 'R$'),
(20, 'Britain (United Kingdom)', 'Pounds', 'GBP', '£'),
(21, 'Brunei Darussalam', 'Dollars', 'BND', '$'),
(22, 'Cambodia', 'Riels', 'KHR', '៛'),
(23, 'Canada', 'Dollars', 'CAD', '$'),
(24, 'Cayman Islands', 'Dollars', 'KYD', '$'),
(25, 'Chile', 'Pesos', 'CLP', '$'),
(26, 'China', 'Yuan Renminbi', 'CNY', '¥'),
(27, 'Colombia', 'Pesos', 'COP', '$'),
(28, 'Costa Rica', 'Colón', 'CRC', '₡'),
(29, 'Croatia', 'Kuna', 'HRK', 'kn'),
(30, 'Cuba', 'Pesos', 'CUP', '₱'),
(31, 'Cyprus', 'Euro', 'EUR', '€'),
(32, 'Czech Republic', 'Koruny', 'CZK', 'Kč'),
(33, 'Denmark', 'Kroner', 'DKK', 'kr'),
(34, 'Dominican Republic', 'Pesos', 'DOP ', 'RD$'),
(35, 'East Caribbean', 'Dollars', 'XCD', '$'),
(36, 'Egypt', 'Pounds', 'EGP', '£'),
(37, 'El Salvador', 'Colones', 'SVC', '$'),
(38, 'England (United Kingdom)', 'Pounds', 'GBP', '£'),
(39, 'Euro', 'Euro', 'EUR', '€'),
(40, 'Falkland Islands', 'Pounds', 'FKP', '£'),
(41, 'Fiji', 'Dollars', 'FJD', '$'),
(42, 'France', 'Euro', 'EUR', '€'),
(43, 'Ghana', 'Cedis', 'GHC', '¢'),
(44, 'Gibraltar', 'Pounds', 'GIP', '£'),
(45, 'Greece', 'Euro', 'EUR', '€'),
(46, 'Guatemala', 'Quetzales', 'GTQ', 'Q'),
(47, 'Guernsey', 'Pounds', 'GGP', '£'),
(48, 'Guyana', 'Dollars', 'GYD', '$'),
(49, 'Holland (Netherlands)', 'Euro', 'EUR', '€'),
(50, 'Honduras', 'Lempiras', 'HNL', 'L'),
(51, 'Hong Kong', 'Dollars', 'HKD', '$'),
(52, 'Hungary', 'Forint', 'HUF', 'Ft'),
(53, 'Iceland', 'Kronur', 'ISK', 'kr'),
(54, 'India', 'Rupees', 'INR', 'Rp.'),
(55, 'Indonesia', 'Rupiahs', 'IDR', 'Rp.'),
(56, 'Iran', 'Rials', 'IRR', '﷼'),
(57, 'Ireland', 'Euro', 'EUR', '€'),
(58, 'Isle of Man', 'Pounds', 'IMP', '£'),
(59, 'Israel', 'New Shekels', 'ILS', '₪'),
(60, 'Italy', 'Euro', 'EUR', '€'),
(61, 'Jamaica', 'Dollars', 'JMD', 'J$'),
(62, 'Japan', 'Yen', 'JPY', '¥'),
(63, 'Jersey', 'Pounds', 'JEP', '£'),
(64, 'Kazakhstan', 'Tenge', 'KZT', 'лв'),
(65, 'Korea (North)', 'Won', 'KPW', '₩'),
(66, 'Korea (South)', 'Won', 'KRW', '₩'),
(67, 'Kyrgyzstan', 'Soms', 'KGS', 'лв'),
(68, 'Laos', 'Kips', 'LAK', '₭'),
(69, 'Latvia', 'Lati', 'LVL', 'Ls'),
(70, 'Lebanon', 'Pounds', 'LBP', '£'),
(71, 'Liberia', 'Dollars', 'LRD', '$'),
(72, 'Liechtenstein', 'Switzerland Francs', 'CHF', 'CHF'),
(73, 'Lithuania', 'Litai', 'LTL', 'Lt'),
(74, 'Luxembourg', 'Euro', 'EUR', '€'),
(75, 'Macedonia', 'Denars', 'MKD', 'ден'),
(76, 'Malaysia', 'Ringgits', 'MYR', 'RM'),
(77, 'Malta', 'Euro', 'EUR', '€'),
(78, 'Mauritius', 'Rupees', 'MUR', '₨'),
(79, 'Mexico', 'Pesos', 'MXN', '$'),
(80, 'Mongolia', 'Tugriks', 'MNT', '₮'),
(81, 'Mozambique', 'Meticais', 'MZN', 'MT'),
(82, 'Namibia', 'Dollars', 'NAD', '$'),
(83, 'Nepal', 'Rupees', 'NPR', '₨'),
(84, 'Netherlands Antilles', 'Guilders', 'ANG', 'ƒ'),
(85, 'Netherlands', 'Euro', 'EUR', '€'),
(86, 'New Zealand', 'Dollars', 'NZD', '$'),
(87, 'Nicaragua', 'Cordobas', 'NIO', 'C$'),
(88, 'Nigeria', 'Nairas', 'NGN', '₦'),
(89, 'North Korea', 'Won', 'KPW', '₩'),
(90, 'Norway', 'Krone', 'NOK', 'kr'),
(91, 'Oman', 'Rials', 'OMR', '﷼'),
(92, 'Pakistan', 'Rupees', 'PKR', '₨'),
(93, 'Panama', 'Balboa', 'PAB', 'B/.'),
(94, 'Paraguay', 'Guarani', 'PYG', 'Gs'),
(95, 'Peru', 'Nuevos Soles', 'PEN', 'S/.'),
(96, 'Philippines', 'Pesos', 'PHP', 'Php'),
(97, 'Poland', 'Zlotych', 'PLN', 'zł'),
(98, 'Qatar', 'Rials', 'QAR', '﷼'),
(99, 'Romania', 'New Lei', 'RON', 'lei'),
(100, 'Russia', 'Rubles', 'RUB', 'руб'),
(101, 'Saint Helena', 'Pounds', 'SHP', '£'),
(102, 'Saudi Arabia', 'Riyals', 'SAR', '﷼'),
(103, 'Serbia', 'Dinars', 'RSD', 'Дин.'),
(104, 'Seychelles', 'Rupees', 'SCR', '₨'),
(105, 'Singapore', 'Dollars', 'SGD', '$'),
(106, 'Slovenia', 'Euro', 'EUR', '€'),
(107, 'Solomon Islands', 'Dollars', 'SBD', '$'),
(108, 'Somalia', 'Shillings', 'SOS', 'S'),
(109, 'South Africa', 'Rand', 'ZAR', 'R'),
(110, 'South Korea', 'Won', 'KRW', '₩'),
(111, 'Spain', 'Euro', 'EUR', '€'),
(112, 'Sri Lanka', 'Rupees', 'LKR', '₨'),
(113, 'Sweden', 'Kronor', 'SEK', 'kr'),
(114, 'Switzerland', 'Francs', 'CHF', 'CHF'),
(115, 'Suriname', 'Dollars', 'SRD', '$'),
(116, 'Syria', 'Pounds', 'SYP', '£'),
(117, 'Taiwan', 'New Dollars', 'TWD', 'NT$'),
(118, 'Thailand', 'Baht', 'THB', '฿'),
(119, 'Trinidad and Tobago', 'Dollars', 'TTD', 'TT$'),
(120, 'Turkey', 'Lira', 'TRY', 'TL'),
(121, 'Turkey', 'Liras', 'TRL', '£'),
(122, 'Tuvalu', 'Dollars', 'TVD', '$'),
(123, 'Ukraine', 'Hryvnia', 'UAH', '₴'),
(124, 'United Kingdom', 'Pounds', 'GBP', '£'),
(125, 'United States of America', 'Dollars', 'USD', '$'),
(126, 'Uruguay', 'Pesos', 'UYU', 'U$'),
(127, 'Uzbekistan', 'Sums', 'UZS', 'лв'),
(128, 'Vatican City', 'Euro', 'EUR', '€'),
(129, 'Venezuela', 'Bolivares Fuertes', 'VEF', 'Bs'),
(130, 'Vietnam', 'Dong', 'VND', '₫'),
(131, 'Yemen', 'Rials', 'YER', '﷼'),
(132, 'Zimbabwe', 'Zimbabwe Dollars', 'ZWD', 'Z$');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dep_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `diagon_bills`
--

DROP TABLE IF EXISTS `diagon_bills`;
CREATE TABLE `diagon_bills` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `invoice` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivary_date` date NOT NULL,
  `delivary_time` time NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `sub_total` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount_percent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `discount_overall` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount_total` decimal(8,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(8,2) NOT NULL DEFAULT '0.00',
  `paid_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `actual_paid_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `due` decimal(8,2) NOT NULL DEFAULT '0.00',
  `due_collection` decimal(8,2) NOT NULL DEFAULT '0.00',
  `change` decimal(8,2) NOT NULL DEFAULT '0.00',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `referral_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `patient_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `trans_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `diagon_bill_items`
--

DROP TABLE IF EXISTS `diagon_bill_items`;
CREATE TABLE `diagon_bill_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `bill_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `test_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `test_price` decimal(8,2) NOT NULL DEFAULT '0.00',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `patient_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `diagon_referral_payments`
--

DROP TABLE IF EXISTS `diagon_referral_payments`;
CREATE TABLE `diagon_referral_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `referral_id` bigint(20) UNSIGNED NOT NULL,
  `trans_id` int(11) NOT NULL DEFAULT '0',
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `description` text COLLATE utf8mb4_unicode_ci,
  `module` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `diagon_test_categories`
--

DROP TABLE IF EXISTS `diagon_test_categories`;
CREATE TABLE `diagon_test_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commission` double(5,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `diagon_test_categories`
--

INSERT INTO `diagon_test_categories` (`id`, `category`, `commission`, `created_at`, `updated_at`) VALUES
(1, 'Pathological', 0.00, '2021-01-02 09:33:02', '2021-01-02 09:33:02'),
(3, 'BIOCHEMICAL TEST', 0.00, '2021-01-02 09:51:33', '2021-01-02 09:51:33'),
(4, 'SEROLOGICAL TEXT', 0.00, '2021-01-02 09:52:37', '2021-01-02 09:52:37'),
(5, 'SEROLOGICAL TEXT', 0.00, '2021-01-02 09:52:38', '2021-01-02 09:52:38'),
(6, 'UIRINE TEST', 0.00, '2021-01-02 09:53:23', '2021-01-02 09:53:23'),
(7, 'UL TRASONOGRAOHY', 0.00, '2021-01-02 09:54:09', '2021-01-02 09:54:09');

-- --------------------------------------------------------

--
-- Table structure for table `diagon_test_lists`
--

DROP TABLE IF EXISTS `diagon_test_lists`;
CREATE TABLE `diagon_test_lists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  `test_category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `diagon_test_lists`
--

INSERT INTO `diagon_test_lists` (`id`, `name`, `price`, `count`, `test_category_id`, `created_at`, `updated_at`) VALUES
(2, 'CBC', 400, 1, 1, '2021-01-02 09:37:58', '2021-01-02 09:44:45'),
(3, 'TCE', 200, 1, 1, '2021-01-02 09:39:50', '2021-01-02 09:44:51'),
(4, 'BLOOD GROUP', 100, 1, 1, '2021-01-02 09:40:26', '2021-01-02 09:44:47'),
(5, 'BT', 200, 1, 1, '2021-01-02 09:40:47', '2021-01-02 09:44:50'),
(6, 'CT', 200, 1, 1, '2021-01-02 09:41:20', '2021-01-02 09:44:48'),
(7, 'WIDAL TEST', 350, 1, 1, '2021-01-02 09:41:56', '2021-01-02 09:44:49'),
(8, 'A S O TITRE', 350, 1, 1, '2021-01-02 09:42:39', '2021-01-02 09:44:49'),
(9, 'R A TEST', 350, 0, 1, '2021-01-02 09:50:22', '2021-01-02 09:50:22');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
CREATE TABLE `doctors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `full_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `own_user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `picture` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` enum('Male','Female') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Male',
  `blood_group` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'A+',
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `biography` text COLLATE utf8mb4_unicode_ci,
  `age` int(11) DEFAULT NULL,
  `marital_status` enum('Married','Single') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Single',
  `religion` enum('Islam','Hindu','Buddha','Christian','Other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Islam',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `full_name`, `email`, `department_id`, `user_id`, `own_user_id`, `picture`, `gender`, `blood_group`, `designation`, `phone_no`, `mobile_no`, `address`, `biography`, `age`, `marital_status`, `religion`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Dr Hasan', 'abc@gmail.com', 1, 5, 4, '', 'Male', 'A+', 'MBBS', '041351315', '', NULL, '', NULL, 'Single', 'Islam', 'Active', '2021-01-02 08:19:53', '2021-01-02 08:19:53');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_payments`
--

DROP TABLE IF EXISTS `doctor_payments`;
CREATE TABLE `doctor_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `doctor_id` bigint(20) UNSIGNED NOT NULL,
  `trans_id` int(11) NOT NULL DEFAULT '0',
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `description` text COLLATE utf8mb4_unicode_ci,
  `module` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doc_appointments`
--

DROP TABLE IF EXISTS `doc_appointments`;
CREATE TABLE `doc_appointments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `invoice` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `patient_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `doctor_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `doc_schedule_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `referral_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `trans_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `doctor_fees` decimal(8,2) NOT NULL,
  `discount` decimal(8,2) DEFAULT NULL,
  `net_fees` decimal(8,2) NOT NULL,
  `serial` int(11) NOT NULL DEFAULT '0',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `status` enum('Requested','Confirmed','Paid','Closed','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Confirmed',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doc_schedules`
--

DROP TABLE IF EXISTS `doc_schedules`;
CREATE TABLE `doc_schedules` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doctor_fees` decimal(8,2) NOT NULL,
  `week_day` enum('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday') COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `visit_qty` int(11) NOT NULL DEFAULT '20',
  `doctor_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `due_collections`
--

DROP TABLE IF EXISTS `due_collections`;
CREATE TABLE `due_collections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trans_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `description` text COLLATE utf8mb4_unicode_ci,
  `patient_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `module` enum('Pharmacy','Diagnostic','Hospital') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pharmacy',
  `sub_module` enum('Hospital-Admission','Hospital-Emergency','Hospital-Operation') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `due_collection_items`
--

DROP TABLE IF EXISTS `due_collection_items`;
CREATE TABLE `due_collection_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `patient_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `due_collection_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `table_id` int(11) NOT NULL,
  `table` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
CREATE TABLE `email_templates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cc_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `email_templates`
--

INSERT INTO `email_templates` (`id`, `name`, `slug`, `subject`, `content`, `description`, `from_name`, `from_email`, `cc_email`, `created_at`, `updated_at`) VALUES
(1, 'Forget Password', 'forget-password', 'Password Recovery', '<p>Hey [name],</p><p>Are you forget your password,</p><p>Here is your link of reset your password:</p><p>[link]</p><p>Thank you for using our system.</p><p>&nbsp;</p><p>Andit Team</p><p>Khulna, Bangladesh</p>', 'Recovery password', 'Shariful Islam', 'shariful.info55@gmail.com', '', '2021-01-02 08:19:51', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
CREATE TABLE `expenses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `expense_category_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_type` enum('bank','cash') COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_transaction_id` int(11) NOT NULL DEFAULT '0',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `module` enum('Pharmacy','Diagnostic','Hospital') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pharmacy',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expense_categories`
--

DROP TABLE IF EXISTS `expense_categories`;
CREATE TABLE `expense_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hms_admissions`
--

DROP TABLE IF EXISTS `hms_admissions`;
CREATE TABLE `hms_admissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `invoice` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admit_date` date NOT NULL,
  `admit_time` time NOT NULL,
  `sub_total` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount_percent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `discount_overall` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount_total` decimal(8,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(8,2) NOT NULL DEFAULT '0.00',
  `paid_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `actual_paid_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `due` decimal(8,2) NOT NULL DEFAULT '0.00',
  `due_collection` decimal(8,2) NOT NULL DEFAULT '0.00',
  `change` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discharge_date` date DEFAULT NULL,
  `discharge_time` time DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `bed_id` bigint(20) UNSIGNED DEFAULT NULL,
  `patient_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `trans_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `referral_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `status` enum('Active','Void','Discharged') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hms_beds`
--

DROP TABLE IF EXISTS `hms_beds`;
CREATE TABLE `hms_beds` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(8,2) NOT NULL DEFAULT '0.00',
  `bed_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `patient` int(11) NOT NULL DEFAULT '0',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `bed_type_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hms_bed_types`
--

DROP TABLE IF EXISTS `hms_bed_types`;
CREATE TABLE `hms_bed_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hms_emergencies`
--

DROP TABLE IF EXISTS `hms_emergencies`;
CREATE TABLE `hms_emergencies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `invoice` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` time NOT NULL,
  `sub_total` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount_percent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `discount_overall` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount_total` decimal(8,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(8,2) NOT NULL DEFAULT '0.00',
  `paid_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `actual_paid_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `due` decimal(8,2) NOT NULL DEFAULT '0.00',
  `due_collection` decimal(8,2) NOT NULL DEFAULT '0.00',
  `change` decimal(8,2) NOT NULL DEFAULT '0.00',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `patient_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `referral_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `trans_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hms_emergency_services`
--

DROP TABLE IF EXISTS `hms_emergency_services`;
CREATE TABLE `hms_emergency_services` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hms_emergency_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `service_date` date NOT NULL,
  `service_id` int(11) NOT NULL DEFAULT '0',
  `service_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `patient_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `service_price` decimal(8,2) NOT NULL DEFAULT '0.00',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hms_given_services`
--

DROP TABLE IF EXISTS `hms_given_services`;
CREATE TABLE `hms_given_services` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `admission_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `service_id` int(11) NOT NULL DEFAULT '0',
  `service_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `patient_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `service_price` decimal(8,2) NOT NULL DEFAULT '0.00',
  `service_date` date NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hms_operations`
--

DROP TABLE IF EXISTS `hms_operations`;
CREATE TABLE `hms_operations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `invoice` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `operation_service_id` bigint(20) UNSIGNED NOT NULL,
  `operation_service_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_service_price` int(11) NOT NULL,
  `discount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(8,2) NOT NULL DEFAULT '0.00',
  `paid_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `due` decimal(8,2) NOT NULL DEFAULT '0.00',
  `change` decimal(8,2) NOT NULL DEFAULT '0.00',
  `actual_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `due_collection` decimal(8,2) NOT NULL DEFAULT '0.00',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `trans_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `patient_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `admission_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hms_operation_services`
--

DROP TABLE IF EXISTS `hms_operation_services`;
CREATE TABLE `hms_operation_services` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `operation_type_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hms_operation_types`
--

DROP TABLE IF EXISTS `hms_operation_types`;
CREATE TABLE `hms_operation_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hms_services`
--

DROP TABLE IF EXISTS `hms_services`;
CREATE TABLE `hms_services` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `service_category_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hms_service_categories`
--

DROP TABLE IF EXISTS `hms_service_categories`;
CREATE TABLE `hms_service_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_attendances`
--

DROP TABLE IF EXISTS `hrm_attendances`;
CREATE TABLE `hrm_attendances` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `emp_id` bigint(20) UNSIGNED NOT NULL,
  `time` time NOT NULL,
  `status` enum('In','Out') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Out',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_departments`
--

DROP TABLE IF EXISTS `hrm_departments`;
CREATE TABLE `hrm_departments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_employees`
--

DROP TABLE IF EXISTS `hrm_employees`;
CREATE TABLE `hrm_employees` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `basic_salary` int(11) NOT NULL,
  `gross_salary` int(11) NOT NULL,
  `date_of_birth` date NOT NULL,
  `joining_date` date NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` enum('Male','Female','Other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Female',
  `marital_status` enum('Married','Single') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Single',
  `picture` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_contact` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `department_id` bigint(20) UNSIGNED NOT NULL,
  `position_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_emp_paid_salary_structures`
--

DROP TABLE IF EXISTS `hrm_emp_paid_salary_structures`;
CREATE TABLE `hrm_emp_paid_salary_structures` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `emp_id` bigint(20) UNSIGNED NOT NULL,
  `hrm_salary_id` bigint(20) UNSIGNED NOT NULL,
  `structure` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `percent` decimal(8,2) NOT NULL DEFAULT '0.00',
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `type` enum('Add','Deduct') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Add',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_emp_salary_structures`
--

DROP TABLE IF EXISTS `hrm_emp_salary_structures`;
CREATE TABLE `hrm_emp_salary_structures` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `emp_id` bigint(20) UNSIGNED NOT NULL,
  `salary_structure_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_positions`
--

DROP TABLE IF EXISTS `hrm_positions`;
CREATE TABLE `hrm_positions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_salaries`
--

DROP TABLE IF EXISTS `hrm_salaries`;
CREATE TABLE `hrm_salaries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `month` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_by` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `basic_salary` int(11) NOT NULL,
  `gross_salary` int(11) NOT NULL,
  `addamount` int(11) DEFAULT NULL,
  `deductamount` int(11) DEFAULT NULL,
  `thismonthamount` int(11) DEFAULT NULL,
  `status` enum('Pending','Paid') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `emp_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `salary_track_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hrm_salary_structures`
--

DROP TABLE IF EXISTS `hrm_salary_structures`;
CREATE TABLE `hrm_salary_structures` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `type` enum('Add','Deduct') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Add',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lab_reports`
--

DROP TABLE IF EXISTS `lab_reports`;
CREATE TABLE `lab_reports` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `invoice` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diagon_bill_id` bigint(20) UNSIGNED NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `patient_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mailboxes`
--

DROP TABLE IF EXISTS `mailboxes`;
CREATE TABLE `mailboxes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `to` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci,
  `attachments` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('read','unread') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unread',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_07_02_230147_migration_cartalyst_sentinel', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_06_27_074025_create_users_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_10_22_113244_create_activities_table', 1),
(6, '2019_10_23_091624_create_notifications_table', 1),
(7, '2019_10_27_064926_create_pharma_categories_table', 1),
(8, '2019_11_02_110046_create_email_templates_table', 1),
(9, '2019_11_03_072451_create_mailboxes_table', 1),
(10, '2019_11_06_075152_create_pharma_manufacturers_table', 1),
(11, '2019_11_06_120046_create_pharma_product_types_table', 1),
(12, '2019_11_07_031254_create_pharma_units_table', 1),
(13, '2019_11_07_053637_create_pharma_product_taxes_table', 1),
(14, '2019_11_07_065045_create_pharma_products_table', 1),
(15, '2019_11_09_041712_create_pharma_purchases_table', 1),
(16, '2019_11_09_043136_create_pharma_purchase_items_table', 1),
(17, '2019_11_12_030343_create_patients_table', 1),
(18, '2019_11_16_073707_create_pharma_batches_table', 1),
(19, '2019_11_23_064050_create_pharma_sales_table', 1),
(20, '2019_11_23_074659_create_pharma_sale_items_table', 1),
(21, '2019_11_24_052552_create_site_settings_table', 1),
(22, '2019_12_05_030221_create_banks_table', 1),
(23, '2019_12_05_084230_create_bank_transections_table', 1),
(24, '2019_12_05_092839_create_transations_table', 1),
(25, '2019_12_08_080852_create_expense_categories_table', 1),
(26, '2019_12_08_081024_create_expenses_table', 1),
(27, '2019_12_15_120623_create_pharma_taxes_table', 1),
(28, '2019_12_21_104442_create_currencies_table', 1),
(29, '2020_01_11_131905_create_referral_categories_table', 1),
(30, '2020_01_12_191953_create_referrals_table', 1),
(31, '2020_01_13_153549_create_diagon_test_categories', 1),
(32, '2020_01_13_155421_create_diagon_test_lists_table', 1),
(33, '2020_01_18_140350_create_diagon_bills_table', 1),
(34, '2020_01_18_140453_create_diagon_bill_items_table', 1),
(35, '2020_01_21_180825_create_diagon_referral_payments_table', 1),
(36, '2020_01_27_121634_create_hms_bed_types_table', 1),
(37, '2020_01_27_122438_create_hms_beds_table', 1),
(38, '2020_01_27_123630_create_hms_service_categories_table', 1),
(39, '2020_01_27_124207_create_hms_services', 1),
(40, '2020_02_02_171347_create_hms_admissions_table', 1),
(41, '2020_02_02_171456_create_hms_given_services_table', 1),
(42, '2020_02_11_162936_create_hms_operation_types_table', 1),
(43, '2020_02_11_164119_create_hms_operation_services_table', 1),
(44, '2020_02_11_164300_create_hms_operations_table', 1),
(45, '2020_02_12_112653_create_due_collections_table', 1),
(46, '2020_02_12_112801_create_due_collection_items_table', 1),
(47, '2020_02_15_143048_create_hms_emergencies_table', 1),
(48, '2020_02_15_143627_create_hms_emergency_services_table', 1),
(49, '2020_02_18_122130_create_bed_charge_collections_table', 1),
(50, '2020_02_18_122321_create_bed_charge_collection_items_table', 1),
(51, '2020_02_23_115535_create_departments_table', 1),
(52, '2020_02_23_115657_create_doctors_table', 1),
(53, '2020_02_23_121955_create_doc_schedules_table', 1),
(54, '2020_02_23_122824_create_doc_appointments_table', 1),
(55, '2020_02_26_171633_create_doctor_payments_table', 1),
(56, '2020_03_01_180808_create_pre_medicine_types_table', 1),
(57, '2020_03_02_180622_create_prescriptions_table', 1),
(58, '2020_03_02_180744_create_pre_medicines_table', 1),
(59, '2020_03_02_180836_create_pre_medicine_items_table', 1),
(60, '2020_03_02_180854_create_pre_test_items_table', 1),
(61, '2020_03_02_191535_create_pre_routines_table', 1),
(62, '2020_03_09_194208_create_lab_reports_table', 1),
(63, '2020_03_15_123510_create_hrm_departments_table', 1),
(64, '2020_03_15_123511_create_hrm_positions_table', 1),
(65, '2020_03_15_123512_create_hrm_employees_table', 1),
(66, '2020_03_15_123513_create_hrm_salary_structures_table', 1),
(67, '2020_03_15_123514_create_hrm_emp_salary_structures_table', 1),
(68, '2020_03_15_123515_create_salary_tracks_table', 1),
(69, '2020_03_15_123516_create_hrm_salaries_table', 1),
(70, '2020_03_15_131803_create_hrm_attendances_table', 1),
(71, '2020_03_16_131645_create_hrm_emp_paid_salary_structures_table', 1),
(72, '2020_03_24_125647_create_asset_categories_table', 1),
(73, '2020_03_24_125730_create_asset_locations_table', 1),
(74, '2020_03_24_125755_create_asset_equipments_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `from` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
CREATE TABLE `patients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `patient_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int(11) DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `picture` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` enum('Male','Female','Other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Female',
  `marital_status` enum('Married','Single') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Single',
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `blood_group` enum('A+','A-','B+','B-','O+','O-','AB+','AB-') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'A+',
  `guardian` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `relationship` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guardian_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupation` enum('Business','Professional','Student','House Wife','Labourers','Other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Business',
  `religion` enum('Islam','Hindu','Buddha','Christian','Other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Islam',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `patient_name`, `slug`, `email`, `phone`, `age`, `address`, `description`, `picture`, `attachment`, `password`, `gender`, `marital_status`, `status`, `blood_group`, `guardian`, `relationship`, `guardian_phone`, `occupation`, `religion`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Walking customer', '0001', NULL, '01700000000', 0, '23', NULL, '', NULL, NULL, 'Male', 'Married', 'Active', 'A+', NULL, NULL, NULL, 'Business', 'Islam', 1, '2021-01-02 08:22:07', '2021-01-02 08:22:07');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(11) DEFAULT '0',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `parent_id`, `name`, `slug`, `description`) VALUES
(1, 0, 'User Management', 'user-management', 'Getting User Management Menus'),
(2, 1, 'User Menu', 'user-menu', 'Getting User Menus'),
(3, 1, 'User list', 'user-index', 'Can view all user list'),
(4, 1, 'View User', 'user-view', 'Can view a user'),
(5, 1, 'Add User', 'user-add', 'Can add a user'),
(6, 1, 'store User', 'user-store', 'Can store a user'),
(7, 1, 'Edit User', 'user-edit', 'Can edit a user'),
(8, 1, 'update User', 'user-update', 'Can update user'),
(9, 1, 'delete User', 'user-delete', 'Can update user'),
(10, 1, 'Role Menu', 'role-menu', 'Getting Role Menus'),
(11, 1, 'role list', 'role-index', 'Can view all role list'),
(12, 1, 'View role', 'role-view', 'Can view a role'),
(13, 1, 'Add role', 'role-add', 'Can add a role'),
(14, 1, 'store role', 'role-store', 'Can store a role'),
(15, 1, 'Edit role', 'role-edit', 'Can edit a role'),
(16, 1, 'update role', 'role-update', 'Can update role'),
(17, 1, 'delete role', 'role-delete', 'Can update role'),
(18, 1, 'permission Menu', 'permission-menu', 'Getting permission Menus'),
(19, 1, 'permission list', 'permission-index', 'Can view all permission list'),
(20, 1, 'View permission', 'permission-view', 'Can view a permission'),
(21, 1, 'Add permission', 'permission-add', 'Can add a permission'),
(22, 1, 'store permission', 'permission-store', 'Can store a permission'),
(23, 1, 'Edit permission', 'permission-edit', 'Can edit a permission'),
(24, 1, 'update permission', 'permission-update', 'Can update permission'),
(25, 1, 'delete permission', 'permission-delete', 'Can update permission'),
(26, 1, 'User Activities', 'activities', 'View all user activities'),
(27, 1, 'Notifacations', 'notifacation', 'View all Notifacation'),
(28, 0, 'Products Management', 'product-management', 'Getting Product Management Menus'),
(29, 28, 'Category list', 'category-index', 'Can View all categories'),
(30, 28, 'Add category', 'category-create', 'Can add a category'),
(31, 28, 'Category view', 'category-show', 'Can View a category'),
(32, 28, 'Edit category', 'category-edit', 'Can edit a category'),
(33, 28, 'delete category', 'category-destroy', 'Can delete a category'),
(34, 28, 'type list', 'type-index', 'Can View all types'),
(35, 28, 'Add type', 'type-create', 'Can add a type'),
(36, 28, 'type view', 'type-show', 'Can View a type'),
(37, 28, 'Edit type', 'type-edit', 'Can edit a type'),
(38, 28, 'delete type', 'type-destroy', 'Can delete a type'),
(39, 28, 'Unit list', 'unit-index', 'Can View all units'),
(40, 28, 'Add unit', 'unit-create', 'Can add a unit'),
(41, 28, 'view unit', 'unit-show', 'Can View a unit'),
(42, 28, 'Edit unit', 'unit-edit', 'Can edit a unit'),
(43, 28, 'delete unit', 'unit-destroy', 'Can delete a unit'),
(44, 28, 'Tax list', 'tax-index', 'Can View all taxes'),
(45, 28, 'Add tax', 'tax-create', 'Can add a tax'),
(46, 28, 'view tax', 'tax-show', 'Can View a tax'),
(47, 28, 'Edit tax', 'tax-edit', 'Can edit a tax'),
(48, 28, 'delete tax', 'tax-destroy', 'Can delete a tax'),
(49, 28, 'product list', 'product-index', 'Can View all productes'),
(50, 28, 'Add product', 'product-create', 'Can add a product'),
(51, 28, 'Show product', 'product-show', 'Can View a product'),
(52, 28, 'Edit product', 'product-edit', 'Can edit a product'),
(53, 28, 'active/inactive product', 'product-destroy', 'Can change status of product'),
(54, 0, 'Manufacturer Management', 'Manufacturer-management', 'Getting Manufacturer Management Menus'),
(55, 54, 'Manufactur list', 'manufacturer-index', 'Can View all Manufacturer'),
(56, 54, 'Add manufacturs', 'manufacturer-create', 'Can add a Manufacturer'),
(57, 54, 'unit manufacturs', 'manufacturer-show', 'Can View a Manufacturer'),
(58, 54, 'Edit manufacturs', 'manufacturer-edit', 'Can edit a Manufacturer'),
(59, 54, 'delete manufacturs', 'manufacturer-destroy', 'Can delete a Manufacturer'),
(60, 0, 'Customer Management', 'Customer-management', 'Getting Customer Management Menus'),
(61, 60, 'Customer list', 'customer-index', 'Can View all customer'),
(62, 60, 'Add customer', 'customer-create', 'Can add a customer'),
(63, 60, 'view customer', 'customer-show', 'Can View a customer'),
(64, 60, 'Edit customer', 'customer-edit', 'Can edit a customer'),
(65, 60, 'delete customer', 'customer-destroy', 'Can delete a customer'),
(66, 0, 'Purchase Management', 'purchase-management', 'Getting Customer purchase Menus'),
(67, 66, 'purchase list', 'purchase-index', 'Can View all purchase'),
(68, 66, 'Add purchase', 'purchase-create', 'Can add a purchase'),
(69, 66, 'view purchase', 'purchase-show', 'Can View a purchase'),
(70, 66, 'Edit purchase', 'purchase-edit', 'Can edit a purchase'),
(71, 66, 'delete purchase', 'purchase-destroy', 'Can delete a purchase'),
(72, 66, 'purchaseReturn list', 'purchaseReturn-index', 'Can View all purchaseReturn'),
(73, 66, 'Add purchaseReturn', 'purchaseReturn-create', 'Can add a purchaseReturn'),
(74, 66, 'view purchaseReturn', 'purchaseReturn-show', 'Can View a purchaseReturn'),
(75, 66, 'Edit purchaseReturn', 'purchaseReturn-edit', 'Can edit a purchaseReturn'),
(76, 66, 'delete purchaseReturn', 'purchaseReturn-destroy', 'Can delete a purchaseReturn'),
(77, 0, 'Sale Management', 'sale-management', 'Getting Customer sale Menus'),
(78, 77, 'See all sale', 'sale-index', 'Can View all sale otherwise only able to see own sale'),
(79, 77, 'Add sale', 'sale-create', 'Can add a sale'),
(80, 77, 'view sale', 'sale-show', 'Can View a sale'),
(81, 77, 'Edit sale', 'sale-edit', 'Can edit a sale'),
(82, 77, 'Void sale', 'sale-destroy', 'Can void a sale'),
(83, 77, 'saleReturn list', 'saleReturn-index', 'Can View all saleReturn'),
(84, 77, 'Add saleReturn', 'saleReturn-create', 'Can add a saleReturn'),
(85, 77, 'view saleReturn', 'saleReturn-show', 'Can View a saleReturn'),
(86, 77, 'Edit saleReturn', 'saleReturn-edit', 'Can edit a saleReturn'),
(87, 77, 'delete saleReturn', 'saleReturn-destroy', 'Can delete a saleReturn'),
(88, 0, 'Site Settings', 'site-setting', 'Setting the site info'),
(89, 88, 'site list', 'siteSetting-index', 'Can View all sale'),
(91, 88, 'site info', 'siteSetting-show', 'Can View info of the site'),
(92, 88, 'Edit site', 'siteSetting-edit', 'Can edit a site info'),
(93, 0, 'Bank Management', 'bank-management', 'Setting the site info'),
(94, 93, 'bankaccount list', 'bankaccount-index', 'Can View all bankaccount'),
(95, 93, 'bankaccount info', 'bankaccount-show', 'Can View info of the bankaccount'),
(96, 93, 'bankaccount edit', 'bankaccount-edit', 'Can edit a bankaccount info'),
(97, 93, 'bankaccount create', 'bankaccount-create', 'Can create all bankaccount'),
(98, 93, 'Bank tranction Create', 'bankTransaction-create', 'Can create Bank tranction'),
(99, 93, 'Bank tranction list', 'bankTransaction-index', 'Can show list all bank'),
(100, 93, 'Bank tranction list', 'bankTransaction-show', 'Can show bank transaction'),
(101, 0, 'Accounts', 'account-management', 'Setting the site info'),
(102, 101, 'transaction list', 'transaction-index', 'Can View all transaction'),
(103, 101, 'transaction info', 'transaction-show', 'Can View info of the transaction'),
(104, 101, 'transaction edit', 'transaction-edit', 'Can edit a transaction info'),
(105, 101, 'transaction create', 'transaction-makepayment', 'Can pay transaction amount'),
(106, 101, 'transaction receoved', 'transaction-receivedpayment', 'Can recevied transaction amount'),
(107, 0, 'Expense', 'expense-management', 'expense the site info'),
(108, 107, 'expenseCategory Management-list', 'expenseCategory-index', 'Can View all expenseCategory'),
(109, 107, 'expenseCategory info', 'expenseCategory-show', 'Can View info of the expenseCategory'),
(110, 107, 'expenseCategory edit', 'expenseCategory-edit', 'Can edit a expenseCategory info'),
(111, 107, 'expenseCategory create', 'expenseCategory-create', 'Can pay expenseCategory amount'),
(112, 107, 'expense list', 'expense-index', 'Can View all expense'),
(113, 107, 'expense info', 'expense-show', 'Can View info of the expense'),
(114, 107, 'expense edit', 'expense-edit', 'Can edit a expense info'),
(115, 107, 'expense create', 'expense-create', 'Can pay expense amount'),
(116, 107, 'expense destroy', 'expense-destroy', 'Can delete expense'),
(117, 107, 'expense create', 'expense-receivedpayment', 'Can recevied expense amount'),
(118, 0, 'Reports', 'report-management', 'Reports Module'),
(119, 118, 'sale report', 'report-sale', 'Can View all sale report'),
(120, 118, 'purchase report', 'report-purchase', 'Can View all purchase report'),
(121, 118, 'expense report', 'report-expense', 'Can View all expense report'),
(122, 118, 'payments report', 'report-payments', 'Can View all payments report'),
(123, 118, 'received report', 'report-received', 'Can View all received report'),
(124, 118, 'p&l report', 'report-p&l', 'Can View all p&l report'),
(125, 118, 'income-statement report', 'report-income-statement', 'Can View all income-statement report'),
(126, 118, 'purchase-return report', 'report-purchase-return', 'Can View all purchase-return report'),
(127, 118, 'sales-return report', 'report-sales-return', 'Can View all sales-return report'),
(128, 118, 'cash-flow report', 'report-cash-flow', 'Can View all cash-flow report'),
(129, 118, 'Todays report', 'report-today', 'Can View todays report'),
(130, 0, 'Stocks', 'stock-management', 'stock Module'),
(131, 130, 'expiry stock', 'stock-expiry', 'Can View all expiry stock'),
(132, 130, 'closing stock', 'stock-closing', 'Can View all closing stock'),
(133, 130, 'batch stock', 'stock-batch', 'Can View all batch stock'),
(134, 130, 'low stock', 'stock-low', 'Can View all low stock'),
(135, 0, 'Taxes', 'tax-management', 'Tax Module'),
(136, 135, 'Tax List', 'tax-index', 'Can View all Tax List'),
(137, 135, 'Pay Tax', 'tax-pay', 'Can pay taxes'),
(138, 28, 'Can Add Batch', 'batch-create', 'Can create a product batch'),
(139, 28, 'Can Delete Batch', 'batch-destroy', 'Can delete a product batch'),
(140, 77, 'Restore void', 'sale-voidrestore', 'Can restore a voided sale'),
(141, 28, 'Export/Import', 'product-export-import', 'Product export import option');

-- --------------------------------------------------------

--
-- Table structure for table `persistences`
--

DROP TABLE IF EXISTS `persistences`;
CREATE TABLE `persistences` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `persistences`
--

INSERT INTO `persistences` (`id`, `user_id`, `code`, `created_at`, `updated_at`) VALUES
(1, 1, 'T3wWFurBlZ6zApeylaXi8rLCjB5jW0an', '2021-01-02 08:20:19', '2021-01-02 08:20:19'),
(2, 5, 'OFKGDrpD4u2EJM1zQoZmCh5kxjLIBVCM', '2021-01-02 08:26:11', '2021-01-02 08:26:11'),
(3, 1, '10Q3VpK24QLcXWOP6QcNcsE07PYadtpS', '2021-01-02 09:30:07', '2021-01-02 09:30:07'),
(4, 6, 'wBKnfd63FttluI364FLPgLaox3umLf31', '2021-01-02 09:44:16', '2021-01-02 09:44:16'),
(5, 1, 'ZEdatdwGYFI9jrNc8FVY9Kgu4gLEL3zt', '2021-01-02 09:45:16', '2021-01-02 09:45:16'),
(6, 1, 'qHWnxubZkWHJLmcnsUeDPE6cPgrZVlgu', '2021-01-02 11:01:16', '2021-01-02 11:01:16'),
(7, 1, 'UKjWu8AauSsvvkq5m7bl0yeVngVL4F8h', '2021-01-02 14:17:27', '2021-01-02 14:17:27');

-- --------------------------------------------------------

--
-- Table structure for table `pharma_batches`
--

DROP TABLE IF EXISTS `pharma_batches`;
CREATE TABLE `pharma_batches` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `purchase_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `purchase_item_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `batch_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `in_stock` int(11) NOT NULL,
  `expiry_date` date NOT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharma_categories`
--

DROP TABLE IF EXISTS `pharma_categories`;
CREATE TABLE `pharma_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharma_manufacturers`
--

DROP TABLE IF EXISTS `pharma_manufacturers`;
CREATE TABLE `pharma_manufacturers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `manufacturer_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `manufacturer_balance` double DEFAULT '0',
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharma_products`
--

DROP TABLE IF EXISTS `pharma_products`;
CREATE TABLE `pharma_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `generic_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `box_size` int(11) NOT NULL DEFAULT '0',
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax` decimal(8,2) DEFAULT '0.00',
  `purchase_price` decimal(8,2) NOT NULL DEFAULT '0.00',
  `sale_price` decimal(8,2) NOT NULL DEFAULT '0.00',
  `stock` int(11) NOT NULL DEFAULT '0',
  `shelf_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `unit_id` bigint(20) UNSIGNED NOT NULL,
  `manufacturer_id` bigint(20) UNSIGNED NOT NULL,
  `product_type_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharma_product_taxes`
--

DROP TABLE IF EXISTS `pharma_product_taxes`;
CREATE TABLE `pharma_product_taxes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tax_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharma_product_types`
--

DROP TABLE IF EXISTS `pharma_product_types`;
CREATE TABLE `pharma_product_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharma_purchases`
--

DROP TABLE IF EXISTS `pharma_purchases`;
CREATE TABLE `pharma_purchases` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `invoice` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `purchase_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `tax_percent` decimal(8,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(6,2) NOT NULL DEFAULT '0.00',
  `payable_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `trans_id` int(11) NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `manufacturer_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharma_purchase_items`
--

DROP TABLE IF EXISTS `pharma_purchase_items`;
CREATE TABLE `pharma_purchase_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `manufacturer_id` bigint(20) UNSIGNED NOT NULL,
  `purchase_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `qty` int(11) NOT NULL,
  `unit_price` decimal(8,2) NOT NULL DEFAULT '0.00',
  `total_price` decimal(8,2) NOT NULL DEFAULT '0.00',
  `was_stock` int(11) NOT NULL DEFAULT '0',
  `new_stock` int(11) NOT NULL DEFAULT '0',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharma_sales`
--

DROP TABLE IF EXISTS `pharma_sales`;
CREATE TABLE `pharma_sales` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `invoice` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `sub_total` decimal(8,2) NOT NULL DEFAULT '0.00',
  `invoice_discount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `total_discount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `tax_percent` decimal(8,2) NOT NULL DEFAULT '0.00',
  `total_tax` decimal(8,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(8,2) NOT NULL DEFAULT '0.00',
  `paid_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `new_balance` decimal(8,2) NOT NULL DEFAULT '0.00',
  `due_collection` decimal(8,2) NOT NULL DEFAULT '0.00',
  `change` decimal(8,2) NOT NULL DEFAULT '0.00',
  `trans_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `patient_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharma_sale_items`
--

DROP TABLE IF EXISTS `pharma_sale_items`;
CREATE TABLE `pharma_sale_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `patient_id` bigint(20) UNSIGNED NOT NULL,
  `sale_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `batch_id` bigint(20) UNSIGNED NOT NULL,
  `current_stock` int(11) NOT NULL,
  `expiry_date` date NOT NULL,
  `sale_qty` int(11) NOT NULL,
  `unit_price` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount_percent` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `total_price` decimal(8,2) NOT NULL DEFAULT '0.00',
  `new_stock` int(11) NOT NULL DEFAULT '0',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharma_taxes`
--

DROP TABLE IF EXISTS `pharma_taxes`;
CREATE TABLE `pharma_taxes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `sale_id` bigint(20) UNSIGNED NOT NULL,
  `sale_invoice` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `payment` enum('Due','Paid') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Due',
  `status` enum('Void','Active') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharma_units`
--

DROP TABLE IF EXISTS `pharma_units`;
CREATE TABLE `pharma_units` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `unit_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prescriptions`
--

DROP TABLE IF EXISTS `prescriptions`;
CREATE TABLE `prescriptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `invoice` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `symptoms` text COLLATE utf8mb4_unicode_ci,
  `diagnosis` text COLLATE utf8mb4_unicode_ci,
  `advices` text COLLATE utf8mb4_unicode_ci,
  `next_appointment` date NOT NULL,
  `patient_id` bigint(20) UNSIGNED NOT NULL,
  `appointment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `doctor_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('Active','Void','Draft') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pre_medicines`
--

DROP TABLE IF EXISTS `pre_medicines`;
CREATE TABLE `pre_medicines` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `count` int(11) DEFAULT NULL,
  `pre_medicine_type_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pre_medicine_items`
--

DROP TABLE IF EXISTS `pre_medicine_items`;
CREATE TABLE `pre_medicine_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `medicine` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dose` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `days` int(11) NOT NULL,
  `use_time` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `pre_medicine_id` bigint(20) UNSIGNED NOT NULL,
  `prescription_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pre_medicine_types`
--

DROP TABLE IF EXISTS `pre_medicine_types`;
CREATE TABLE `pre_medicine_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pre_routines`
--

DROP TABLE IF EXISTS `pre_routines`;
CREATE TABLE `pre_routines` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pre_medicine_type_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pre_test_items`
--

DROP TABLE IF EXISTS `pre_test_items`;
CREATE TABLE `pre_test_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `test` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `diagon_test_id` bigint(20) UNSIGNED NOT NULL,
  `prescription_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `referrals`
--

DROP TABLE IF EXISTS `referrals`;
CREATE TABLE `referrals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(5,2) NOT NULL DEFAULT '0.00',
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral_category_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `referrals`
--

INSERT INTO `referrals` (`id`, `name`, `price`, `designation`, `contact`, `email`, `referral_category_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'self', '0.00', 'self', '01900000000', NULL, 1, 1, '2021-01-02 08:21:17', '2021-01-02 08:21:17');

-- --------------------------------------------------------

--
-- Table structure for table `referral_categories`
--

DROP TABLE IF EXISTS `referral_categories`;
CREATE TABLE `referral_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(5,2) NOT NULL DEFAULT '0.00',
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `referral_categories`
--

INSERT INTO `referral_categories` (`id`, `cat_name`, `price`, `slug`, `status`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'self', '0.00', 'self', 'Active', 1, '2021-01-02 08:20:44', '2021-01-02 08:20:44');

-- --------------------------------------------------------

--
-- Table structure for table `reminders`
--

DROP TABLE IF EXISTS `reminders`;
CREATE TABLE `reminders` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `slug`, `name`, `permissions`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Admin', '{\"user-management\":true,\"user-menu\":true,\"user-index\":true,\"user-view\":true,\"user-add\":true,\"user-store\":true,\"user-edit\":true,\"user-update\":true,\"user-delete\":true,\"role-menu\":true,\"role-index\":true,\"role-view\":true,\"role-add\":true,\"role-store\":true,\"role-edit\":true,\"role-update\":true,\"role-delete\":true,\"permission-menu\":true,\"permission-index\":true,\"permission-view\":true,\"permission-add\":true,\"permission-store\":true,\"permission-edit\":true,\"permission-update\":true,\"permission-delete\":true,\"activities\":true,\"notifacation\":true,\"product-management\":true,\"category-index\":true,\"category-create\":true,\"category-show\":true,\"category-edit\":true,\"category-destroy\":true,\"type-index\":true,\"type-create\":true,\"type-show\":true,\"type-edit\":true,\"type-destroy\":true,\"unit-index\":true,\"unit-create\":true,\"unit-show\":true,\"unit-edit\":true,\"unit-destroy\":true,\"tax-index\":true,\"tax-create\":true,\"tax-show\":true,\"tax-edit\":true,\"tax-destroy\":true,\"product-index\":true,\"product-create\":true,\"product-show\":true,\"product-edit\":true,\"product-destroy\":true,\"Manufacturer-management\":true,\"manufacturer-index\":true,\"manufacturer-create\":true,\"manufacturer-show\":true,\"manufacturer-edit\":true,\"manufacturer-destroy\":true,\"Customer-management\":true,\"customer-index\":true,\"customer-create\":true,\"customer-show\":true,\"customer-edit\":true,\"customer-destroy\":true,\"purchase-management\":true,\"purchase-index\":true,\"purchase-create\":true,\"purchase-show\":true,\"purchase-edit\":true,\"purchase-destroy\":true,\"purchaseReturn-index\":true,\"purchaseReturn-create\":true,\"purchaseReturn-show\":true,\"purchaseReturn-edit\":true,\"purchaseReturn-destroy\":true,\"sale-management\":true,\"sale-index\":true,\"sale-create\":true,\"sale-show\":true,\"sale-edit\":true,\"sale-destroy\":true,\"saleReturn-index\":true,\"saleReturn-create\":true,\"saleReturn-show\":true,\"saleReturn-edit\":true,\"saleReturn-destroy\":true,\"site-setting\":true,\"siteSetting-index\":true,\"siteSetting-show\":true,\"siteSetting-edit\":true,\"bank-management\":true,\"bankaccount-index\":true,\"bankaccount-show\":true,\"bankaccount-edit\":true,\"bankaccount-create\":true,\"bankTransaction-create\":true,\"bankTransaction-index\":true,\"bankTransaction-show\":true,\"account-management\":true,\"transaction-index\":true,\"transaction-show\":true,\"transaction-edit\":true,\"transaction-makepayment\":true,\"transaction-receivedpayment\":true,\"expense-management\":true,\"expenseCategory-index\":true,\"expenseCategory-show\":true,\"expenseCategory-edit\":true,\"expenseCategory-create\":true,\"expense-index\":true,\"expense-show\":true,\"expense-edit\":true,\"expense-create\":true,\"expense-destroy\":true,\"expense-receivedpayment\":true,\"report-management\":true,\"report-sale\":true,\"report-purchase\":true,\"report-expense\":true,\"report-payments\":true,\"report-received\":true,\"report-p&l\":true,\"report-income-statement\":true,\"report-purchase-return\":true,\"report-sales-return\":true,\"report-cash-flow\":true,\"report-today\":true,\"stock-management\":true,\"stock-expiry\":true,\"stock-closing\":true,\"stock-batch\":true,\"stock-low\":true,\"tax-management\":true,\"tax-index\":true,\"tax-pay\":true,\"batch-create\":true,\"batch-destroy\":true,\"sale-voidrestore\":true,\"product-export-import\":true}', '2021-01-02 08:19:37', '2021-01-02 08:19:37'),
(2, 'laboratory', 'Laboratory', '{\"notifacation\":true,\"activities\":true,\"product-management\":true,\"batch-destroy\":true,\"batch-create\":true,\"product-destroy\":true,\"product-edit\":true,\"product-show\":true,\"product-create\":true,\"product-index\":true,\"tax-destroy\":true,\"tax-edit\":true,\"tax-show\":true,\"tax-create\":true,\"tax-index\":true,\"unit-destroy\":true,\"unit-edit\":true,\"unit-show\":true,\"unit-create\":true,\"unit-index\":true,\"type-destroy\":true,\"type-edit\":true,\"type-show\":true,\"type-create\":true,\"type-index\":true,\"category-destroy\":true,\"category-edit\":true,\"category-show\":true,\"category-create\":true,\"category-index\":true,\"Manufacturer-management\":true,\"manufacturer-destroy\":true,\"manufacturer-edit\":true,\"manufacturer-show\":true,\"manufacturer-create\":true,\"manufacturer-index\":true,\"Customer-management\":true,\"customer-destroy\":true,\"customer-edit\":true,\"customer-show\":true,\"customer-create\":true,\"customer-index\":true,\"purchase-management\":true,\"purchaseReturn-destroy\":true,\"purchaseReturn-edit\":true,\"purchaseReturn-show\":true,\"purchaseReturn-create\":true,\"purchaseReturn-index\":true,\"purchase-destroy\":true,\"purchase-edit\":true,\"purchase-show\":true,\"purchase-create\":true,\"purchase-index\":true,\"sale-management\":true,\"saleReturn-destroy\":true,\"saleReturn-edit\":true,\"saleReturn-show\":true,\"saleReturn-create\":true,\"saleReturn-index\":true,\"sale-edit\":true,\"sale-show\":true,\"sale-create\":true,\"sale-index\":true,\"bank-management\":true,\"bankTransaction-show\":true,\"bankTransaction-index\":true,\"bankTransaction-create\":true,\"bankaccount-create\":true,\"bankaccount-edit\":true,\"bankaccount-show\":true,\"bankaccount-index\":true,\"account-management\":true,\"transaction-receivedpayment\":true,\"transaction-makepayment\":true,\"transaction-edit\":true,\"transaction-show\":true,\"transaction-index\":true,\"expense-management\":true,\"expense-receivedpayment\":true,\"expense-destroy\":true,\"expense-create\":true,\"expense-edit\":true,\"expense-show\":true,\"expense-index\":true,\"expenseCategory-create\":true,\"expenseCategory-edit\":true,\"expenseCategory-show\":true,\"expenseCategory-index\":true,\"report-management\":true,\"report-today\":true,\"report-cash-flow\":true,\"report-sales-return\":true,\"report-purchase-return\":true,\"report-income-statement\":true,\"report-p&l\":true,\"report-received\":true,\"report-payments\":true,\"report-expense\":true,\"report-purchase\":true,\"report-sale\":true,\"stock-management\":true,\"stock-low\":true,\"stock-batch\":true,\"stock-closing\":true,\"stock-expiry\":true,\"tax-management\":true,\"tax-pay\":true}', '2021-01-02 08:19:37', '2021-01-02 08:19:37'),
(3, 'pharmacy', 'Pharmacy', '{\"notifacation\":true,\"activities\":true,\"product-management\":true,\"batch-destroy\":true,\"batch-create\":true,\"product-destroy\":true,\"product-edit\":true,\"product-show\":true,\"product-create\":true,\"product-index\":true,\"tax-destroy\":true,\"tax-edit\":true,\"tax-show\":true,\"tax-create\":true,\"tax-index\":true,\"unit-destroy\":true,\"unit-edit\":true,\"unit-show\":true,\"unit-create\":true,\"unit-index\":true,\"type-destroy\":true,\"type-edit\":true,\"type-show\":true,\"type-create\":true,\"type-index\":true,\"category-destroy\":true,\"category-edit\":true,\"category-show\":true,\"category-create\":true,\"category-index\":true,\"Manufacturer-management\":true,\"manufacturer-destroy\":true,\"manufacturer-edit\":true,\"manufacturer-show\":true,\"manufacturer-create\":true,\"manufacturer-index\":true,\"Customer-management\":true,\"customer-destroy\":true,\"customer-edit\":true,\"customer-show\":true,\"customer-create\":true,\"customer-index\":true,\"purchase-management\":true,\"purchaseReturn-destroy\":true,\"purchaseReturn-edit\":true,\"purchaseReturn-show\":true,\"purchaseReturn-create\":true,\"purchaseReturn-index\":true,\"purchase-destroy\":true,\"purchase-edit\":true,\"purchase-show\":true,\"purchase-create\":true,\"purchase-index\":true,\"sale-management\":true,\"saleReturn-destroy\":true,\"saleReturn-edit\":true,\"saleReturn-show\":true,\"saleReturn-create\":true,\"saleReturn-index\":true,\"sale-edit\":true,\"sale-show\":true,\"sale-create\":true,\"sale-index\":true,\"bank-management\":true,\"bankTransaction-show\":true,\"bankTransaction-index\":true,\"bankTransaction-create\":true,\"bankaccount-create\":true,\"bankaccount-edit\":true,\"bankaccount-show\":true,\"bankaccount-index\":true,\"account-management\":true,\"transaction-receivedpayment\":true,\"transaction-makepayment\":true,\"transaction-edit\":true,\"transaction-show\":true,\"transaction-index\":true,\"expense-management\":true,\"expense-receivedpayment\":true,\"expense-destroy\":true,\"expense-create\":true,\"expense-edit\":true,\"expense-show\":true,\"expense-index\":true,\"expenseCategory-create\":true,\"expenseCategory-edit\":true,\"expenseCategory-show\":true,\"expenseCategory-index\":true,\"report-management\":true,\"report-today\":true,\"report-cash-flow\":true,\"report-sales-return\":true,\"report-purchase-return\":true,\"report-income-statement\":true,\"report-p&l\":true,\"report-received\":true,\"report-payments\":true,\"report-expense\":true,\"report-purchase\":true,\"report-sale\":true,\"stock-management\":true,\"stock-low\":true,\"stock-batch\":true,\"stock-closing\":true,\"stock-expiry\":true,\"tax-management\":true,\"tax-pay\":true}', '2021-01-02 08:19:37', '2021-01-02 08:19:37'),
(4, 'doctor', 'Doctor', '{\"notifacation\":true,\"activities\":true,\"product-management\":true,\"product-edit\":true,\"product-show\":true,\"product-create\":true,\"product-index\":true,\"tax-destroy\":true,\"tax-edit\":true,\"tax-show\":true,\"tax-create\":true,\"tax-index\":true,\"unit-destroy\":true,\"unit-edit\":true,\"unit-show\":true,\"unit-create\":true,\"unit-index\":true,\"type-destroy\":true,\"type-edit\":true,\"type-show\":true,\"type-create\":true,\"type-index\":true,\"category-destroy\":true,\"category-edit\":true,\"category-show\":true,\"category-create\":true,\"category-index\":true,\"customer-create\":true,\"sale-management\":true,\"saleReturn-destroy\":true,\"saleReturn-show\":true,\"saleReturn-index\":true,\"sale-show\":true,\"sale-create\":true,\"report-management\":true,\"report-today\":true,\"report-sale\":true,\"stock-management\":true,\"stock-low\":true,\"stock-batch\":true,\"stock-closing\":true,\"stock-expiry\":true}', '2021-01-02 08:19:37', '2021-01-02 08:19:37'),
(5, 'manager', 'Manager', '{\"user-management\":true,\"user-menu\":true,\"user-index\":true,\"user-view\":true,\"user-add\":true,\"user-store\":true,\"user-edit\":true,\"user-update\":true,\"user-delete\":true,\"role-menu\":true,\"role-index\":true,\"role-view\":true,\"role-add\":true,\"role-store\":true,\"role-edit\":true,\"role-update\":true,\"role-delete\":true,\"permission-menu\":true,\"permission-index\":true,\"permission-view\":true,\"permission-add\":true,\"permission-store\":true,\"permission-edit\":true,\"permission-update\":true,\"permission-delete\":true,\"activities\":true,\"notifacation\":true,\"product-management\":true,\"category-index\":true,\"category-create\":true,\"category-show\":true,\"category-edit\":true,\"category-destroy\":true,\"type-index\":true,\"type-create\":true,\"type-show\":true,\"type-edit\":true,\"type-destroy\":true,\"unit-index\":true,\"unit-create\":true,\"unit-show\":true,\"unit-edit\":true,\"unit-destroy\":true,\"tax-index\":true,\"tax-create\":true,\"tax-show\":true,\"tax-edit\":true,\"tax-destroy\":true,\"product-index\":true,\"product-create\":true,\"product-show\":true,\"product-edit\":true,\"product-destroy\":true,\"Manufacturer-management\":true,\"manufacturer-index\":true,\"manufacturer-create\":true,\"manufacturer-show\":true,\"manufacturer-edit\":true,\"manufacturer-destroy\":true,\"Customer-management\":true,\"customer-index\":true,\"customer-create\":true,\"customer-show\":true,\"customer-edit\":true,\"customer-destroy\":true,\"purchase-management\":true,\"purchase-index\":true,\"purchase-create\":true,\"purchase-show\":true,\"purchase-edit\":true,\"purchase-destroy\":true,\"purchaseReturn-index\":true,\"purchaseReturn-create\":true,\"purchaseReturn-show\":true,\"purchaseReturn-edit\":true,\"purchaseReturn-destroy\":true,\"sale-management\":true,\"sale-index\":true,\"sale-create\":true,\"sale-show\":true,\"sale-edit\":true,\"sale-destroy\":true,\"saleReturn-index\":true,\"saleReturn-create\":true,\"saleReturn-show\":true,\"saleReturn-edit\":true,\"saleReturn-destroy\":true,\"site-setting\":true,\"siteSetting-index\":true,\"siteSetting-show\":true,\"siteSetting-edit\":true,\"bank-management\":true,\"bankaccount-index\":true,\"bankaccount-show\":true,\"bankaccount-edit\":true,\"bankaccount-create\":true,\"bankTransaction-create\":true,\"bankTransaction-index\":true,\"bankTransaction-show\":true,\"account-management\":true,\"transaction-index\":true,\"transaction-show\":true,\"transaction-edit\":true,\"transaction-makepayment\":true,\"transaction-receivedpayment\":true,\"expense-management\":true,\"expenseCategory-index\":true,\"expenseCategory-show\":true,\"expenseCategory-edit\":true,\"expenseCategory-create\":true,\"expense-index\":true,\"expense-show\":true,\"expense-edit\":true,\"expense-create\":true,\"expense-destroy\":true,\"expense-receivedpayment\":true,\"report-management\":true,\"report-sale\":true,\"report-purchase\":true,\"report-expense\":true,\"report-payments\":true,\"report-received\":true,\"report-p&l\":true,\"report-income-statement\":true,\"report-purchase-return\":true,\"report-sales-return\":true,\"report-cash-flow\":true,\"report-today\":true,\"stock-management\":true,\"stock-expiry\":true,\"stock-closing\":true,\"stock-batch\":true,\"stock-low\":true,\"tax-management\":true,\"tax-index\":true,\"tax-pay\":true,\"batch-create\":true,\"batch-destroy\":true,\"sale-voidrestore\":true,\"product-export-import\":true}', '2021-01-02 08:19:37', '2021-01-02 08:19:37'),
(6, 'receptionist', 'Receptionist', '{\"notifacation\":true,\"activities\":true,\"product-management\":true,\"product-edit\":true,\"product-show\":true,\"product-create\":true,\"product-index\":true,\"tax-destroy\":true,\"tax-edit\":true,\"tax-show\":true,\"tax-create\":true,\"tax-index\":true,\"unit-destroy\":true,\"unit-edit\":true,\"unit-show\":true,\"unit-create\":true,\"unit-index\":true,\"type-destroy\":true,\"type-edit\":true,\"type-show\":true,\"type-create\":true,\"type-index\":true,\"category-destroy\":true,\"category-edit\":true,\"category-show\":true,\"category-create\":true,\"category-index\":true,\"customer-create\":true,\"sale-management\":true,\"saleReturn-destroy\":true,\"saleReturn-show\":true,\"saleReturn-index\":true,\"sale-show\":true,\"sale-create\":true,\"report-management\":true,\"report-today\":true,\"report-sale\":true,\"stock-management\":true,\"stock-low\":true,\"stock-batch\":true,\"stock-closing\":true,\"stock-expiry\":true}', '2021-01-02 08:19:37', '2021-01-02 08:19:37');

-- --------------------------------------------------------

--
-- Table structure for table `role_users`
--

DROP TABLE IF EXISTS `role_users`;
CREATE TABLE `role_users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_users`
--

INSERT INTO `role_users` (`user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2021-01-02 08:19:40', '2021-01-02 08:19:40'),
(2, 3, '2021-01-02 08:19:42', '2021-01-02 08:19:42'),
(3, 2, '2021-01-02 08:19:44', '2021-01-02 08:19:44'),
(4, 4, '2021-01-02 08:19:47', '2021-01-02 08:19:47'),
(5, 5, '2021-01-02 08:19:49', '2021-01-02 08:19:49'),
(6, 6, '2021-01-02 08:19:51', '2021-01-02 08:19:51');

-- --------------------------------------------------------

--
-- Table structure for table `salary_tracks`
--

DROP TABLE IF EXISTS `salary_tracks`;
CREATE TABLE `salary_tracks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date DEFAULT NULL,
  `month` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
CREATE TABLE `site_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `site_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login_banar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reg_banar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Asia/Dhaka',
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '2',
  `currency_symbol` varchar(191) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '$',
  `cur_position` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'before',
  `date_format` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'M d, Y',
  `sale_prefix` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SALE',
  `purchase_prefix` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PUR',
  `transaction_prefix` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TRNS',
  `bank_transaction_prefix` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'BT',
  `sale_return_prefix` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SR',
  `purchase_return_prefix` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PR',
  `batch_prefix` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'BATCH',
  `sale_tax` double(8,2) NOT NULL DEFAULT '0.00',
  `purchase_tax` double(8,2) NOT NULL DEFAULT '0.00',
  `voucher_type` enum('A4','POS') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'POS',
  `prefix_diagnostic_bill` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DIA',
  `prefix_hms_admission` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'HMS',
  `prefix_asset` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'hms/assets/',
  `mini_sidebar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'red-dark',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `site_settings`
--

INSERT INTO `site_settings` (`id`, `site_name`, `address`, `phone_number`, `website`, `email`, `logo`, `login_banar`, `reg_banar`, `footer_text`, `language`, `timezone`, `currency`, `currency_symbol`, `cur_position`, `date_format`, `sale_prefix`, `purchase_prefix`, `transaction_prefix`, `bank_transaction_prefix`, `sale_return_prefix`, `purchase_return_prefix`, `batch_prefix`, `sale_tax`, `purchase_tax`, `voucher_type`, `prefix_diagnostic_bill`, `prefix_hms_admission`, `prefix_asset`, `mini_sidebar`, `theme`, `created_at`, `updated_at`) VALUES
(1, 'HMS', 'Road#32, Hamilton Avenue, Singapur', '0000000', 'www.pharma.com', 'pharma@app.com', '', '', '', 'Pharmacy Management System', 'en', 'Asia/Dhaka', '2', '$', 'before', 'M d, Y', 'SALE', 'PUR', 'TRNS', 'BT', 'SR', 'PR', 'BATCH', 0.00, 0.00, 'POS', 'DIA', 'HMS', 'hms/assets/', NULL, 'red-dark', '2021-01-02 08:19:52', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `throttle`
--

DROP TABLE IF EXISTS `throttle`;
CREATE TABLE `throttle` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transations`
--

DROP TABLE IF EXISTS `transations`;
CREATE TABLE `transations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `trans_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `description` text COLLATE utf8mb4_unicode_ci,
  `transaction_way` enum('Bank','Cash') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Cash',
  `bank_transaction_id` int(11) NOT NULL DEFAULT '0',
  `vendor_id` int(11) NOT NULL,
  `vendor` enum('Patient','Manufacturer','Expense','Referral','Doctor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Patient',
  `transaction_type` enum('Payment','Received','Collection') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Received',
  `status` enum('Active','Void') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `module` enum('Pharmacy','Diagnostic','Hospital','Receptionist') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pharmacy',
  `sub_module` enum('Hospital-Admission','Hospital-Emergency','Hospital-Operation','Hospital-BedChargeCollection','Diagnostic-Appointment') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `last_login` timestamp NULL DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_banar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `permissions`, `last_login`, `first_name`, `last_name`, `profile_image`, `profile_banar`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@andit.com', '$2y$10$pVF/XuuJLnt6nqpXne0d8Op0Zp7Tn7hD8BoMoD/jbEsgq5tfng9XG', NULL, '2021-01-02 14:17:27', 'Admin', 'AndIt', NULL, NULL, '2021-01-02 08:19:37', '2021-01-02 14:17:27'),
(2, 'Pharmacy', 'pharma@andit.com', '$2y$10$EvTFcuBMQ0crzTGmaz87bugb4gL7Dtg9GTtlB3XaHP0gq.AfeHS5u', NULL, NULL, 'Pharma Manager', 'AndIt', NULL, NULL, '2021-01-02 08:19:40', '2021-01-02 08:19:40'),
(3, 'Laboratory', 'lab@andit.com', '$2y$10$mIROujzjvDpoTtj5psW5CeFZI.xd13TFV4LoUF02ko/h4.BVxCEku', NULL, NULL, 'Lab Manager', 'AndIt', NULL, NULL, '2021-01-02 08:19:43', '2021-01-02 08:19:43'),
(4, 'Gopal Singh Dhanik', 'drgopal@andit.com', '$2y$10$QgYVx0OcheY2EoTjvjlhh.EnnKAsaN8TEhaEJIJ4QoTrfyWeu8iBi', NULL, NULL, 'Gopal', 'Singh Dhanik', NULL, NULL, '2021-01-02 08:19:45', '2021-01-02 08:19:45'),
(5, 'Manager', 'manager@andit.com', '$2y$10$PMUsv2Z45yM6x.//u3P0t.1EC6ovsn5Jz1vGQSwbAV01i7AtalOYC', NULL, '2021-01-02 08:26:11', 'Manager', 'AndIt', NULL, NULL, '2021-01-02 08:19:47', '2021-01-02 08:26:11'),
(6, 'Tapas', 'receptionist@andit.com', '$2y$10$aVQ2tZR618WtKTHpxLP.Nu568RLp6t25q70MJuC1W.n1gdOB0DZsO', NULL, '2021-01-02 09:44:16', 'Tapas', 'Pal', NULL, NULL, '2021-01-02 08:19:49', '2021-01-02 09:44:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activations`
--
ALTER TABLE `activations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `asset_categories`
--
ALTER TABLE `asset_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_categories_user_id_foreign` (`user_id`);

--
-- Indexes for table `asset_equipment`
--
ALTER TABLE `asset_equipment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_equipment_category_id_foreign` (`category_id`),
  ADD KEY `asset_equipment_location_id_foreign` (`location_id`),
  ADD KEY `asset_equipment_user_id_foreign` (`user_id`);

--
-- Indexes for table `asset_locations`
--
ALTER TABLE `asset_locations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_locations_user_id_foreign` (`user_id`);

--
-- Indexes for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bank_transections`
--
ALTER TABLE `bank_transections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bank_transections_bank_account_id_foreign` (`bank_account_id`),
  ADD KEY `bank_transections_user_id_foreign` (`user_id`);

--
-- Indexes for table `bed_charge_collections`
--
ALTER TABLE `bed_charge_collections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bed_charge_collections_admission_id_foreign` (`admission_id`),
  ADD KEY `bed_charge_collections_patient_id_foreign` (`patient_id`),
  ADD KEY `bed_charge_collections_bed_id_foreign` (`bed_id`),
  ADD KEY `bed_charge_collections_user_id_foreign` (`user_id`);

--
-- Indexes for table `bed_charge_collection_items`
--
ALTER TABLE `bed_charge_collection_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bed_charge_collection_items_bed_charge_collection_id_foreign` (`bed_charge_collection_id`);

--
-- Indexes for table `currencies`
--
ALTER TABLE `currencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `departments_user_id_foreign` (`user_id`);

--
-- Indexes for table `diagon_bills`
--
ALTER TABLE `diagon_bills`
  ADD PRIMARY KEY (`id`),
  ADD KEY `diagon_bills_referral_id_foreign` (`referral_id`),
  ADD KEY `diagon_bills_patient_id_foreign` (`patient_id`),
  ADD KEY `diagon_bills_user_id_foreign` (`user_id`);

--
-- Indexes for table `diagon_bill_items`
--
ALTER TABLE `diagon_bill_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `diagon_bill_items_test_id_foreign` (`test_id`),
  ADD KEY `diagon_bill_items_bill_id_foreign` (`bill_id`),
  ADD KEY `diagon_bill_items_patient_id_foreign` (`patient_id`),
  ADD KEY `diagon_bill_items_user_id_foreign` (`user_id`);

--
-- Indexes for table `diagon_referral_payments`
--
ALTER TABLE `diagon_referral_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `diagon_referral_payments_referral_id_foreign` (`referral_id`),
  ADD KEY `diagon_referral_payments_user_id_foreign` (`user_id`);

--
-- Indexes for table `diagon_test_categories`
--
ALTER TABLE `diagon_test_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `diagon_test_lists`
--
ALTER TABLE `diagon_test_lists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `diagon_test_lists_test_category_id_foreign` (`test_category_id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `doctors_user_id_foreign` (`user_id`),
  ADD KEY `doctors_department_id_foreign` (`department_id`);

--
-- Indexes for table `doctor_payments`
--
ALTER TABLE `doctor_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `doctor_payments_doctor_id_foreign` (`doctor_id`),
  ADD KEY `doctor_payments_user_id_foreign` (`user_id`);

--
-- Indexes for table `doc_appointments`
--
ALTER TABLE `doc_appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `doc_appointments_user_id_foreign` (`user_id`),
  ADD KEY `doc_appointments_doctor_id_foreign` (`doctor_id`),
  ADD KEY `doc_appointments_patient_id_foreign` (`patient_id`),
  ADD KEY `doc_appointments_doc_schedule_id_foreign` (`doc_schedule_id`);

--
-- Indexes for table `doc_schedules`
--
ALTER TABLE `doc_schedules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `doc_schedules_user_id_foreign` (`user_id`),
  ADD KEY `doc_schedules_doctor_id_foreign` (`doctor_id`);

--
-- Indexes for table `due_collections`
--
ALTER TABLE `due_collections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `due_collections_user_id_foreign` (`user_id`),
  ADD KEY `due_collections_patient_id_foreign` (`patient_id`);

--
-- Indexes for table `due_collection_items`
--
ALTER TABLE `due_collection_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `due_collection_items_user_id_foreign` (`user_id`),
  ADD KEY `due_collection_items_patient_id_foreign` (`patient_id`),
  ADD KEY `due_collection_items_due_collection_id_foreign` (`due_collection_id`);

--
-- Indexes for table `email_templates`
--
ALTER TABLE `email_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `expenses_user_id_foreign` (`user_id`),
  ADD KEY `expenses_expense_category_id_foreign` (`expense_category_id`);

--
-- Indexes for table `expense_categories`
--
ALTER TABLE `expense_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `expense_categories_user_id_foreign` (`user_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hms_admissions`
--
ALTER TABLE `hms_admissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hms_admissions_referral_id_foreign` (`referral_id`),
  ADD KEY `hms_admissions_bed_id_foreign` (`bed_id`),
  ADD KEY `hms_admissions_patient_id_foreign` (`patient_id`),
  ADD KEY `hms_admissions_user_id_foreign` (`user_id`);

--
-- Indexes for table `hms_beds`
--
ALTER TABLE `hms_beds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hms_beds_bed_type_id_foreign` (`bed_type_id`),
  ADD KEY `hms_beds_user_id_foreign` (`user_id`);

--
-- Indexes for table `hms_bed_types`
--
ALTER TABLE `hms_bed_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hms_bed_types_user_id_foreign` (`user_id`);

--
-- Indexes for table `hms_emergencies`
--
ALTER TABLE `hms_emergencies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hms_emergencies_referral_id_foreign` (`referral_id`),
  ADD KEY `hms_emergencies_patient_id_foreign` (`patient_id`),
  ADD KEY `hms_emergencies_user_id_foreign` (`user_id`);

--
-- Indexes for table `hms_emergency_services`
--
ALTER TABLE `hms_emergency_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hms_emergency_services_hms_emergency_id_foreign` (`hms_emergency_id`),
  ADD KEY `hms_emergency_services_patient_id_foreign` (`patient_id`),
  ADD KEY `hms_emergency_services_user_id_foreign` (`user_id`);

--
-- Indexes for table `hms_given_services`
--
ALTER TABLE `hms_given_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hms_given_services_admission_id_foreign` (`admission_id`),
  ADD KEY `hms_given_services_patient_id_foreign` (`patient_id`),
  ADD KEY `hms_given_services_user_id_foreign` (`user_id`);

--
-- Indexes for table `hms_operations`
--
ALTER TABLE `hms_operations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hms_operations_operation_service_id_foreign` (`operation_service_id`),
  ADD KEY `hms_operations_patient_id_foreign` (`patient_id`),
  ADD KEY `hms_operations_admission_id_foreign` (`admission_id`),
  ADD KEY `hms_operations_user_id_foreign` (`user_id`);

--
-- Indexes for table `hms_operation_services`
--
ALTER TABLE `hms_operation_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hms_operation_services_operation_type_id_foreign` (`operation_type_id`),
  ADD KEY `hms_operation_services_user_id_foreign` (`user_id`);

--
-- Indexes for table `hms_operation_types`
--
ALTER TABLE `hms_operation_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hms_operation_types_user_id_foreign` (`user_id`);

--
-- Indexes for table `hms_services`
--
ALTER TABLE `hms_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hms_services_service_category_id_foreign` (`service_category_id`),
  ADD KEY `hms_services_user_id_foreign` (`user_id`);

--
-- Indexes for table `hms_service_categories`
--
ALTER TABLE `hms_service_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hms_service_categories_user_id_foreign` (`user_id`);

--
-- Indexes for table `hrm_attendances`
--
ALTER TABLE `hrm_attendances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hrm_attendances_emp_id_foreign` (`emp_id`),
  ADD KEY `hrm_attendances_user_id_foreign` (`user_id`);

--
-- Indexes for table `hrm_departments`
--
ALTER TABLE `hrm_departments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hrm_departments_user_id_foreign` (`user_id`);

--
-- Indexes for table `hrm_employees`
--
ALTER TABLE `hrm_employees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hrm_employees_department_id_foreign` (`department_id`),
  ADD KEY `hrm_employees_position_id_foreign` (`position_id`),
  ADD KEY `hrm_employees_user_id_foreign` (`user_id`);

--
-- Indexes for table `hrm_emp_paid_salary_structures`
--
ALTER TABLE `hrm_emp_paid_salary_structures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hrm_emp_paid_salary_structures_emp_id_foreign` (`emp_id`),
  ADD KEY `hrm_emp_paid_salary_structures_hrm_salary_id_foreign` (`hrm_salary_id`),
  ADD KEY `hrm_emp_paid_salary_structures_user_id_foreign` (`user_id`);

--
-- Indexes for table `hrm_emp_salary_structures`
--
ALTER TABLE `hrm_emp_salary_structures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hrm_emp_salary_structures_emp_id_foreign` (`emp_id`),
  ADD KEY `hrm_emp_salary_structures_salary_structure_id_foreign` (`salary_structure_id`),
  ADD KEY `hrm_emp_salary_structures_user_id_foreign` (`user_id`);

--
-- Indexes for table `hrm_positions`
--
ALTER TABLE `hrm_positions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hrm_positions_user_id_foreign` (`user_id`);

--
-- Indexes for table `hrm_salaries`
--
ALTER TABLE `hrm_salaries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hrm_salaries_emp_id_foreign` (`emp_id`),
  ADD KEY `hrm_salaries_salary_track_id_foreign` (`salary_track_id`),
  ADD KEY `hrm_salaries_user_id_foreign` (`user_id`);

--
-- Indexes for table `hrm_salary_structures`
--
ALTER TABLE `hrm_salary_structures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hrm_salary_structures_user_id_foreign` (`user_id`);

--
-- Indexes for table `lab_reports`
--
ALTER TABLE `lab_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lab_reports_diagon_bill_id_foreign` (`diagon_bill_id`),
  ADD KEY `lab_reports_patient_id_foreign` (`patient_id`),
  ADD KEY `lab_reports_user_id_foreign` (`user_id`);

--
-- Indexes for table `mailboxes`
--
ALTER TABLE `mailboxes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `patients_email_unique` (`email`),
  ADD KEY `patients_user_id_foreign` (`user_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `persistences`
--
ALTER TABLE `persistences`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `persistences_code_unique` (`code`);

--
-- Indexes for table `pharma_batches`
--
ALTER TABLE `pharma_batches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pharma_batches_product_id_foreign` (`product_id`);

--
-- Indexes for table `pharma_categories`
--
ALTER TABLE `pharma_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pharma_categories_slug_unique` (`slug`),
  ADD KEY `pharma_categories_user_id_foreign` (`user_id`);

--
-- Indexes for table `pharma_manufacturers`
--
ALTER TABLE `pharma_manufacturers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pharma_manufacturers_user_id_foreign` (`user_id`);

--
-- Indexes for table `pharma_products`
--
ALTER TABLE `pharma_products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pharma_products_slug_unique` (`slug`),
  ADD KEY `pharma_products_product_type_id_foreign` (`product_type_id`),
  ADD KEY `pharma_products_unit_id_foreign` (`unit_id`),
  ADD KEY `pharma_products_category_id_foreign` (`category_id`),
  ADD KEY `pharma_products_user_id_foreign` (`user_id`),
  ADD KEY `pharma_products_manufacturer_id_foreign` (`manufacturer_id`);

--
-- Indexes for table `pharma_product_taxes`
--
ALTER TABLE `pharma_product_taxes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pharma_product_taxes_slug_unique` (`slug`),
  ADD KEY `pharma_product_taxes_user_id_foreign` (`user_id`);

--
-- Indexes for table `pharma_product_types`
--
ALTER TABLE `pharma_product_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pharma_product_types_slug_unique` (`slug`),
  ADD KEY `pharma_product_types_user_id_foreign` (`user_id`);

--
-- Indexes for table `pharma_purchases`
--
ALTER TABLE `pharma_purchases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pharma_purchases_manufacturer_id_foreign` (`manufacturer_id`),
  ADD KEY `pharma_purchases_user_id_foreign` (`user_id`);

--
-- Indexes for table `pharma_purchase_items`
--
ALTER TABLE `pharma_purchase_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pharma_purchase_items_manufacturer_id_foreign` (`manufacturer_id`),
  ADD KEY `pharma_purchase_items_purchase_id_foreign` (`purchase_id`),
  ADD KEY `pharma_purchase_items_product_id_foreign` (`product_id`);

--
-- Indexes for table `pharma_sales`
--
ALTER TABLE `pharma_sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pharma_sales_patient_id_foreign` (`patient_id`),
  ADD KEY `pharma_sales_user_id_foreign` (`user_id`);

--
-- Indexes for table `pharma_sale_items`
--
ALTER TABLE `pharma_sale_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pharma_sale_items_batch_id_foreign` (`batch_id`),
  ADD KEY `pharma_sale_items_patient_id_foreign` (`patient_id`),
  ADD KEY `pharma_sale_items_sale_id_foreign` (`sale_id`),
  ADD KEY `pharma_sale_items_product_id_foreign` (`product_id`);

--
-- Indexes for table `pharma_taxes`
--
ALTER TABLE `pharma_taxes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pharma_taxes_user_id_foreign` (`user_id`),
  ADD KEY `pharma_taxes_sale_id_foreign` (`sale_id`);

--
-- Indexes for table `pharma_units`
--
ALTER TABLE `pharma_units`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pharma_units_slug_unique` (`slug`),
  ADD KEY `pharma_units_user_id_foreign` (`user_id`);

--
-- Indexes for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `prescriptions_patient_id_foreign` (`patient_id`),
  ADD KEY `prescriptions_doctor_id_foreign` (`doctor_id`),
  ADD KEY `prescriptions_user_id_foreign` (`user_id`);

--
-- Indexes for table `pre_medicines`
--
ALTER TABLE `pre_medicines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pre_medicines_pre_medicine_type_id_foreign` (`pre_medicine_type_id`),
  ADD KEY `pre_medicines_user_id_foreign` (`user_id`);

--
-- Indexes for table `pre_medicine_items`
--
ALTER TABLE `pre_medicine_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pre_medicine_items_prescription_id_foreign` (`prescription_id`),
  ADD KEY `pre_medicine_items_pre_medicine_id_foreign` (`pre_medicine_id`),
  ADD KEY `pre_medicine_items_user_id_foreign` (`user_id`);

--
-- Indexes for table `pre_medicine_types`
--
ALTER TABLE `pre_medicine_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pre_medicine_types_user_id_foreign` (`user_id`);

--
-- Indexes for table `pre_routines`
--
ALTER TABLE `pre_routines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pre_routines_pre_medicine_type_id_foreign` (`pre_medicine_type_id`),
  ADD KEY `pre_routines_user_id_foreign` (`user_id`);

--
-- Indexes for table `pre_test_items`
--
ALTER TABLE `pre_test_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pre_test_items_diagon_test_id_foreign` (`diagon_test_id`),
  ADD KEY `pre_test_items_prescription_id_foreign` (`prescription_id`),
  ADD KEY `pre_test_items_user_id_foreign` (`user_id`);

--
-- Indexes for table `referrals`
--
ALTER TABLE `referrals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `referrals_referral_category_id_foreign` (`referral_category_id`),
  ADD KEY `referrals_user_id_foreign` (`user_id`);

--
-- Indexes for table `referral_categories`
--
ALTER TABLE `referral_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `referral_categories_user_id_foreign` (`user_id`);

--
-- Indexes for table `reminders`
--
ALTER TABLE `reminders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_slug_unique` (`slug`);

--
-- Indexes for table `role_users`
--
ALTER TABLE `role_users`
  ADD PRIMARY KEY (`user_id`,`role_id`);

--
-- Indexes for table `salary_tracks`
--
ALTER TABLE `salary_tracks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `salary_tracks_user_id_foreign` (`user_id`);

--
-- Indexes for table `site_settings`
--
ALTER TABLE `site_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `throttle`
--
ALTER TABLE `throttle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `throttle_user_id_index` (`user_id`);

--
-- Indexes for table `transations`
--
ALTER TABLE `transations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transations_user_id_foreign` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activations`
--
ALTER TABLE `activations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `asset_categories`
--
ALTER TABLE `asset_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `asset_equipment`
--
ALTER TABLE `asset_equipment`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `asset_locations`
--
ALTER TABLE `asset_locations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bank_transections`
--
ALTER TABLE `bank_transections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bed_charge_collections`
--
ALTER TABLE `bed_charge_collections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bed_charge_collection_items`
--
ALTER TABLE `bed_charge_collection_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `currencies`
--
ALTER TABLE `currencies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `diagon_bills`
--
ALTER TABLE `diagon_bills`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `diagon_bill_items`
--
ALTER TABLE `diagon_bill_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `diagon_referral_payments`
--
ALTER TABLE `diagon_referral_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `diagon_test_categories`
--
ALTER TABLE `diagon_test_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `diagon_test_lists`
--
ALTER TABLE `diagon_test_lists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `doctor_payments`
--
ALTER TABLE `doctor_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `doc_appointments`
--
ALTER TABLE `doc_appointments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `doc_schedules`
--
ALTER TABLE `doc_schedules`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `due_collections`
--
ALTER TABLE `due_collections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `due_collection_items`
--
ALTER TABLE `due_collection_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `email_templates`
--
ALTER TABLE `email_templates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expense_categories`
--
ALTER TABLE `expense_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hms_admissions`
--
ALTER TABLE `hms_admissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hms_beds`
--
ALTER TABLE `hms_beds`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hms_bed_types`
--
ALTER TABLE `hms_bed_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hms_emergencies`
--
ALTER TABLE `hms_emergencies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hms_emergency_services`
--
ALTER TABLE `hms_emergency_services`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hms_given_services`
--
ALTER TABLE `hms_given_services`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hms_operations`
--
ALTER TABLE `hms_operations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hms_operation_services`
--
ALTER TABLE `hms_operation_services`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hms_operation_types`
--
ALTER TABLE `hms_operation_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hms_services`
--
ALTER TABLE `hms_services`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hms_service_categories`
--
ALTER TABLE `hms_service_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_attendances`
--
ALTER TABLE `hrm_attendances`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_departments`
--
ALTER TABLE `hrm_departments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_employees`
--
ALTER TABLE `hrm_employees`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_emp_paid_salary_structures`
--
ALTER TABLE `hrm_emp_paid_salary_structures`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_emp_salary_structures`
--
ALTER TABLE `hrm_emp_salary_structures`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_positions`
--
ALTER TABLE `hrm_positions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_salaries`
--
ALTER TABLE `hrm_salaries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hrm_salary_structures`
--
ALTER TABLE `hrm_salary_structures`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lab_reports`
--
ALTER TABLE `lab_reports`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mailboxes`
--
ALTER TABLE `mailboxes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;

--
-- AUTO_INCREMENT for table `persistences`
--
ALTER TABLE `persistences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pharma_batches`
--
ALTER TABLE `pharma_batches`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pharma_categories`
--
ALTER TABLE `pharma_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pharma_manufacturers`
--
ALTER TABLE `pharma_manufacturers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pharma_products`
--
ALTER TABLE `pharma_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pharma_product_taxes`
--
ALTER TABLE `pharma_product_taxes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pharma_product_types`
--
ALTER TABLE `pharma_product_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pharma_purchases`
--
ALTER TABLE `pharma_purchases`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pharma_purchase_items`
--
ALTER TABLE `pharma_purchase_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pharma_sales`
--
ALTER TABLE `pharma_sales`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pharma_sale_items`
--
ALTER TABLE `pharma_sale_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pharma_taxes`
--
ALTER TABLE `pharma_taxes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pharma_units`
--
ALTER TABLE `pharma_units`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prescriptions`
--
ALTER TABLE `prescriptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pre_medicines`
--
ALTER TABLE `pre_medicines`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pre_medicine_items`
--
ALTER TABLE `pre_medicine_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pre_medicine_types`
--
ALTER TABLE `pre_medicine_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pre_routines`
--
ALTER TABLE `pre_routines`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pre_test_items`
--
ALTER TABLE `pre_test_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `referrals`
--
ALTER TABLE `referrals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `referral_categories`
--
ALTER TABLE `referral_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `reminders`
--
ALTER TABLE `reminders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `salary_tracks`
--
ALTER TABLE `salary_tracks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `site_settings`
--
ALTER TABLE `site_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `throttle`
--
ALTER TABLE `throttle`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transations`
--
ALTER TABLE `transations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `asset_categories`
--
ALTER TABLE `asset_categories`
  ADD CONSTRAINT `asset_categories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `asset_equipment`
--
ALTER TABLE `asset_equipment`
  ADD CONSTRAINT `asset_equipment_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `asset_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `asset_equipment_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `asset_locations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `asset_equipment_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `asset_locations`
--
ALTER TABLE `asset_locations`
  ADD CONSTRAINT `asset_locations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bank_transections`
--
ALTER TABLE `bank_transections`
  ADD CONSTRAINT `bank_transections_bank_account_id_foreign` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bank_transections_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bed_charge_collections`
--
ALTER TABLE `bed_charge_collections`
  ADD CONSTRAINT `bed_charge_collections_admission_id_foreign` FOREIGN KEY (`admission_id`) REFERENCES `hms_admissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bed_charge_collections_bed_id_foreign` FOREIGN KEY (`bed_id`) REFERENCES `hms_beds` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bed_charge_collections_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bed_charge_collections_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bed_charge_collection_items`
--
ALTER TABLE `bed_charge_collection_items`
  ADD CONSTRAINT `bed_charge_collection_items_bed_charge_collection_id_foreign` FOREIGN KEY (`bed_charge_collection_id`) REFERENCES `bed_charge_collections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `departments`
--
ALTER TABLE `departments`
  ADD CONSTRAINT `departments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `diagon_bills`
--
ALTER TABLE `diagon_bills`
  ADD CONSTRAINT `diagon_bills_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `diagon_bills_referral_id_foreign` FOREIGN KEY (`referral_id`) REFERENCES `referrals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `diagon_bills_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `diagon_bill_items`
--
ALTER TABLE `diagon_bill_items`
  ADD CONSTRAINT `diagon_bill_items_bill_id_foreign` FOREIGN KEY (`bill_id`) REFERENCES `diagon_bills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `diagon_bill_items_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `diagon_bill_items_test_id_foreign` FOREIGN KEY (`test_id`) REFERENCES `diagon_test_lists` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `diagon_bill_items_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `diagon_referral_payments`
--
ALTER TABLE `diagon_referral_payments`
  ADD CONSTRAINT `diagon_referral_payments_referral_id_foreign` FOREIGN KEY (`referral_id`) REFERENCES `referrals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `diagon_referral_payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `diagon_test_lists`
--
ALTER TABLE `diagon_test_lists`
  ADD CONSTRAINT `diagon_test_lists_test_category_id_foreign` FOREIGN KEY (`test_category_id`) REFERENCES `diagon_test_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doctors`
--
ALTER TABLE `doctors`
  ADD CONSTRAINT `doctors_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `doctors_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doctor_payments`
--
ALTER TABLE `doctor_payments`
  ADD CONSTRAINT `doctor_payments_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `doctor_payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doc_appointments`
--
ALTER TABLE `doc_appointments`
  ADD CONSTRAINT `doc_appointments_doc_schedule_id_foreign` FOREIGN KEY (`doc_schedule_id`) REFERENCES `doc_schedules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `doc_appointments_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `doc_appointments_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `doc_appointments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doc_schedules`
--
ALTER TABLE `doc_schedules`
  ADD CONSTRAINT `doc_schedules_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `doc_schedules_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `due_collections`
--
ALTER TABLE `due_collections`
  ADD CONSTRAINT `due_collections_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `due_collections_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `due_collection_items`
--
ALTER TABLE `due_collection_items`
  ADD CONSTRAINT `due_collection_items_due_collection_id_foreign` FOREIGN KEY (`due_collection_id`) REFERENCES `due_collections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `due_collection_items_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `due_collection_items_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `expenses_expense_category_id_foreign` FOREIGN KEY (`expense_category_id`) REFERENCES `expense_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `expenses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `expense_categories`
--
ALTER TABLE `expense_categories`
  ADD CONSTRAINT `expense_categories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hms_admissions`
--
ALTER TABLE `hms_admissions`
  ADD CONSTRAINT `hms_admissions_bed_id_foreign` FOREIGN KEY (`bed_id`) REFERENCES `hms_beds` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hms_admissions_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hms_admissions_referral_id_foreign` FOREIGN KEY (`referral_id`) REFERENCES `referrals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hms_admissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hms_beds`
--
ALTER TABLE `hms_beds`
  ADD CONSTRAINT `hms_beds_bed_type_id_foreign` FOREIGN KEY (`bed_type_id`) REFERENCES `hms_bed_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hms_beds_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hms_bed_types`
--
ALTER TABLE `hms_bed_types`
  ADD CONSTRAINT `hms_bed_types_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hms_emergencies`
--
ALTER TABLE `hms_emergencies`
  ADD CONSTRAINT `hms_emergencies_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hms_emergencies_referral_id_foreign` FOREIGN KEY (`referral_id`) REFERENCES `referrals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hms_emergencies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hms_emergency_services`
--
ALTER TABLE `hms_emergency_services`
  ADD CONSTRAINT `hms_emergency_services_hms_emergency_id_foreign` FOREIGN KEY (`hms_emergency_id`) REFERENCES `hms_emergencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hms_emergency_services_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hms_emergency_services_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hms_given_services`
--
ALTER TABLE `hms_given_services`
  ADD CONSTRAINT `hms_given_services_admission_id_foreign` FOREIGN KEY (`admission_id`) REFERENCES `hms_admissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hms_given_services_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hms_given_services_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hms_operations`
--
ALTER TABLE `hms_operations`
  ADD CONSTRAINT `hms_operations_admission_id_foreign` FOREIGN KEY (`admission_id`) REFERENCES `hms_admissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hms_operations_operation_service_id_foreign` FOREIGN KEY (`operation_service_id`) REFERENCES `hms_operation_services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hms_operations_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hms_operations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hms_operation_services`
--
ALTER TABLE `hms_operation_services`
  ADD CONSTRAINT `hms_operation_services_operation_type_id_foreign` FOREIGN KEY (`operation_type_id`) REFERENCES `hms_operation_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hms_operation_services_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hms_operation_types`
--
ALTER TABLE `hms_operation_types`
  ADD CONSTRAINT `hms_operation_types_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hms_services`
--
ALTER TABLE `hms_services`
  ADD CONSTRAINT `hms_services_service_category_id_foreign` FOREIGN KEY (`service_category_id`) REFERENCES `hms_service_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hms_services_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hms_service_categories`
--
ALTER TABLE `hms_service_categories`
  ADD CONSTRAINT `hms_service_categories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hrm_attendances`
--
ALTER TABLE `hrm_attendances`
  ADD CONSTRAINT `hrm_attendances_emp_id_foreign` FOREIGN KEY (`emp_id`) REFERENCES `hrm_employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hrm_attendances_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hrm_departments`
--
ALTER TABLE `hrm_departments`
  ADD CONSTRAINT `hrm_departments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hrm_employees`
--
ALTER TABLE `hrm_employees`
  ADD CONSTRAINT `hrm_employees_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `hrm_departments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hrm_employees_position_id_foreign` FOREIGN KEY (`position_id`) REFERENCES `hrm_positions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hrm_employees_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hrm_emp_paid_salary_structures`
--
ALTER TABLE `hrm_emp_paid_salary_structures`
  ADD CONSTRAINT `hrm_emp_paid_salary_structures_emp_id_foreign` FOREIGN KEY (`emp_id`) REFERENCES `hrm_employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hrm_emp_paid_salary_structures_hrm_salary_id_foreign` FOREIGN KEY (`hrm_salary_id`) REFERENCES `hrm_salaries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hrm_emp_paid_salary_structures_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hrm_emp_salary_structures`
--
ALTER TABLE `hrm_emp_salary_structures`
  ADD CONSTRAINT `hrm_emp_salary_structures_emp_id_foreign` FOREIGN KEY (`emp_id`) REFERENCES `hrm_employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hrm_emp_salary_structures_salary_structure_id_foreign` FOREIGN KEY (`salary_structure_id`) REFERENCES `hrm_salary_structures` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hrm_emp_salary_structures_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hrm_positions`
--
ALTER TABLE `hrm_positions`
  ADD CONSTRAINT `hrm_positions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hrm_salaries`
--
ALTER TABLE `hrm_salaries`
  ADD CONSTRAINT `hrm_salaries_emp_id_foreign` FOREIGN KEY (`emp_id`) REFERENCES `hrm_employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hrm_salaries_salary_track_id_foreign` FOREIGN KEY (`salary_track_id`) REFERENCES `salary_tracks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hrm_salaries_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hrm_salary_structures`
--
ALTER TABLE `hrm_salary_structures`
  ADD CONSTRAINT `hrm_salary_structures_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lab_reports`
--
ALTER TABLE `lab_reports`
  ADD CONSTRAINT `lab_reports_diagon_bill_id_foreign` FOREIGN KEY (`diagon_bill_id`) REFERENCES `diagon_bills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lab_reports_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lab_reports_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `patients`
--
ALTER TABLE `patients`
  ADD CONSTRAINT `patients_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pharma_batches`
--
ALTER TABLE `pharma_batches`
  ADD CONSTRAINT `pharma_batches_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `pharma_products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pharma_categories`
--
ALTER TABLE `pharma_categories`
  ADD CONSTRAINT `pharma_categories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pharma_manufacturers`
--
ALTER TABLE `pharma_manufacturers`
  ADD CONSTRAINT `pharma_manufacturers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pharma_products`
--
ALTER TABLE `pharma_products`
  ADD CONSTRAINT `pharma_products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `pharma_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pharma_products_manufacturer_id_foreign` FOREIGN KEY (`manufacturer_id`) REFERENCES `pharma_manufacturers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pharma_products_product_type_id_foreign` FOREIGN KEY (`product_type_id`) REFERENCES `pharma_product_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pharma_products_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `pharma_units` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pharma_products_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pharma_product_taxes`
--
ALTER TABLE `pharma_product_taxes`
  ADD CONSTRAINT `pharma_product_taxes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pharma_product_types`
--
ALTER TABLE `pharma_product_types`
  ADD CONSTRAINT `pharma_product_types_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pharma_purchases`
--
ALTER TABLE `pharma_purchases`
  ADD CONSTRAINT `pharma_purchases_manufacturer_id_foreign` FOREIGN KEY (`manufacturer_id`) REFERENCES `pharma_manufacturers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pharma_purchases_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pharma_purchase_items`
--
ALTER TABLE `pharma_purchase_items`
  ADD CONSTRAINT `pharma_purchase_items_manufacturer_id_foreign` FOREIGN KEY (`manufacturer_id`) REFERENCES `pharma_manufacturers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pharma_purchase_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `pharma_products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pharma_purchase_items_purchase_id_foreign` FOREIGN KEY (`purchase_id`) REFERENCES `pharma_purchases` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pharma_sales`
--
ALTER TABLE `pharma_sales`
  ADD CONSTRAINT `pharma_sales_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pharma_sales_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pharma_sale_items`
--
ALTER TABLE `pharma_sale_items`
  ADD CONSTRAINT `pharma_sale_items_batch_id_foreign` FOREIGN KEY (`batch_id`) REFERENCES `pharma_batches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pharma_sale_items_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pharma_sale_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `pharma_products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pharma_sale_items_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `pharma_sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pharma_taxes`
--
ALTER TABLE `pharma_taxes`
  ADD CONSTRAINT `pharma_taxes_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `pharma_sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pharma_taxes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pharma_units`
--
ALTER TABLE `pharma_units`
  ADD CONSTRAINT `pharma_units_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD CONSTRAINT `prescriptions_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `prescriptions_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `prescriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pre_medicines`
--
ALTER TABLE `pre_medicines`
  ADD CONSTRAINT `pre_medicines_pre_medicine_type_id_foreign` FOREIGN KEY (`pre_medicine_type_id`) REFERENCES `pre_medicine_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pre_medicines_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pre_medicine_items`
--
ALTER TABLE `pre_medicine_items`
  ADD CONSTRAINT `pre_medicine_items_pre_medicine_id_foreign` FOREIGN KEY (`pre_medicine_id`) REFERENCES `pre_medicines` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pre_medicine_items_prescription_id_foreign` FOREIGN KEY (`prescription_id`) REFERENCES `prescriptions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pre_medicine_items_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pre_medicine_types`
--
ALTER TABLE `pre_medicine_types`
  ADD CONSTRAINT `pre_medicine_types_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pre_routines`
--
ALTER TABLE `pre_routines`
  ADD CONSTRAINT `pre_routines_pre_medicine_type_id_foreign` FOREIGN KEY (`pre_medicine_type_id`) REFERENCES `pre_medicine_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pre_routines_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pre_test_items`
--
ALTER TABLE `pre_test_items`
  ADD CONSTRAINT `pre_test_items_diagon_test_id_foreign` FOREIGN KEY (`diagon_test_id`) REFERENCES `diagon_test_lists` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pre_test_items_prescription_id_foreign` FOREIGN KEY (`prescription_id`) REFERENCES `prescriptions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pre_test_items_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `referrals`
--
ALTER TABLE `referrals`
  ADD CONSTRAINT `referrals_referral_category_id_foreign` FOREIGN KEY (`referral_category_id`) REFERENCES `referral_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `referrals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `referral_categories`
--
ALTER TABLE `referral_categories`
  ADD CONSTRAINT `referral_categories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `salary_tracks`
--
ALTER TABLE `salary_tracks`
  ADD CONSTRAINT `salary_tracks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transations`
--
ALTER TABLE `transations`
  ADD CONSTRAINT `transations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
