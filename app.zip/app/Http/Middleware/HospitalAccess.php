<?php

namespace App\Http\Middleware;

use Closure;
use Sentinel;
use Session;
class HospitalAccess
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(Sentinel::getUser()->inRole('hospital') || Sentinel::getUser()->inRole('admin') || Sentinel::getUser()->inRole('receptionist')){
            return $next($request);
        }
        Session::flash('success', 'Sorry You Are Not Authorized!');
        flash('Sorry You Are Not Authorized!')->error();
        return redirect('dashboard');
    }   
}
